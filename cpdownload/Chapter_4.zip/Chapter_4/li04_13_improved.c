/* li04_13_improved.c: 穷举法：百钱百鸡问题的优化 */
#include <stdio.h>

int main( )
{
	int a, b, c, count=0;
	for ( a = 0 ; a <= 20 ; a++ )
	{
		for ( b = 0 ; b <= 33 ; b++ )
		{
			c = 100 - a - b;
			if ( 15 * a + 9 * b + c == 300 )
			{
				printf( "%d, %d, %d\n", a, b, c );
			}
			count++;
		}
	}
	printf("count = %d \n",count);
	return 0;
}
