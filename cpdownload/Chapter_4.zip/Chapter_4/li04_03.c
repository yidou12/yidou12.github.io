/* li04_03.c: if~else示例：求三角形面积的改进 */
#include <stdio.h>
#include <math.h>

int main( )
{
	double edge1, edge2, edge3, p, area;
	printf( "Enter three edges of a triangle:" );
	scanf( "%lf%lf%lf", &edge1, &edge2, &edge3 );
	if ( edge1 > 0 && edge2 > 0 && edge3 > 0 && edge1 + edge2 > edge3 && edge1 + edge3 > edge2 && edge2 + edge3 > edge1 )
														/* 用户输入判断 */
	{
		p = ( edge1 + edge2 + edge3 ) / 2;	
		area = sqrt( p * ( p - edge1 ) * ( p - edge2 ) * ( p - edge3 ) );
		printf( "area = %f\n", area );
	}
	else												/* 不合法时需提示用户 */
	{
		printf( "Error input!\n" );
	}	
	return 0;
}
