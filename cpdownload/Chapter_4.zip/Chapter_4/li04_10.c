/* li04_10.c: 循环嵌套示例：加法表 */
#include <stdio.h>
#define N 9
int main( )
{
	int i, j;
	
	for ( i = 1 ; i <= N ; i++ )					/* 外层循环：控制行数 */
	{
		for ( j = 1 ; j <= i ; j++ )				/* 内存循环：控制输出的等式数 */
		{
			printf( "%d+%d=%2d ", i, j, i+j );		/* 输出具体内容 */
		}
		printf( "\n" );								/* 每行最后应有一个回车换行 */
	}
	return 0;
}
