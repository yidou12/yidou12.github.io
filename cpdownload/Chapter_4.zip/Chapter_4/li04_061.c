/* li04_06.c: while语句示例：求累加和 */
#include <stdio.h>

int main( )
{
	int n, i, sum;
	printf ( "Enter a positive integer : " );
	scanf( "%d", &n );
	if ( n < 0 )								/* 确保n >= 0 */
	{
		n = -n;
	}
	i = 1;
	sum = 0;

	do
	{
		sum += i;
		i++;
	 
	} while ( i <= n );	
	
	printf ( "sum = %d\n", sum );
	return 0;
}
