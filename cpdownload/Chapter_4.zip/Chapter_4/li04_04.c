/* li04_04.c: 嵌套if示例：三角形判别 */
#include <stdio.h>
#include <math.h>

int main( )
{
	double edge1, edge2, edge3;
	printf( "Enter three edges of a triangle:" );
	scanf( "%lf%lf%lf", &edge1, &edge2, &edge3 );
	if ( edge1 <= 0 || edge2 <= 0 || edge3 <= 0 )		/* 输入合法性判别 */
	{
		printf ( "Error input!\n" );
	}
	else
	{	
		/* 三角形判别 */
		if ( edge1 + edge2 > edge3 && edge1 + edge3 > edge2 && edge2 + edge3 > edge1 )
		{
			if ( fabs ( edge1 * edge1 + edge2 * edge2 - edge3 * edge3 ) < 1E-2
				|| fabs ( edge2 * edge2 + edge3 * edge3 - edge1 * edge1 ) < 1E-2
				|| fabs ( edge1 * edge1 + edge3 * edge3 - edge2 * edge2 ) < 1E-2 )
			{
				/* 直角三角形 */
				printf ( "%f, %f, %f is an right triangle.\n", edge1, edge2, edge3 );
			}
			else
			{
				/* 普通三角形 */
				printf ( "%f, %f, %f is an ordinary triangle.\n", edge1, edge2, edge3 );				
			}
		}
		else	/* 不能构成三角形 */
		{
			printf ( "%f, %f, %f is not a triangle.\n", edge1, edge2, edge3 );
		}
		
	}	
	return 0;
}
