/* li04_12.c: 质数判断 */
#include <stdio.h>
#include <math.h>

int main( )
{
	int n, i, k;
	do
	{	
		printf( "Enter a positive integer : " );
		scanf( "%d", &n );
	} while ( n <= 0 );					/* 确保n为正数 */
	if ( n == 1 )
	{
		printf( "%d is not a prime.\n", n );
	}
	else
	{
		k = (int)sqrt(n);
		for ( i = 2 ; i <= k ; i++ )
		{
			if ( n % i == 0 )
			{
				break;
			}
		}
		if ( i > k )
		{
			printf( "%d is a prime.\n", n );
		}
		else
		{
			printf( "%d is not a prime.\n", n );
		}
	}
	return 0;
}
