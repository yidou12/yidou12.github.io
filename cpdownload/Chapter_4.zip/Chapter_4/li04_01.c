/* li04_01.c: 顺序结构示例：求三角形面积 */
#include <stdio.h>
#include <math.h>														/* 包含了函数sqrt原型 */

int main( )
{
	double edge1, edge2, edge3, p, area;
	printf ( "Enter three edges of a triangle: " );						/* 提示用户输入 */
	scanf ( "%lf%lf%lf", &edge1, &edge2, &edge3 );						/* 从键盘读入三条边长 3 4 5*/
	p = ( edge1 + edge2 + edge3 ) / 2;	
	area = sqrt( p * ( p - edge1 ) * ( p - edge2 ) * ( p - edge3 ) ); 	/* 使用数学公式求面积 */
	printf ( "area = %lf\n", area );									/* 输出面积 */
	return 0;
}
