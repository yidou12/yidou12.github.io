/* li04_13.c: 穷举法：百钱百鸡问题 */
#include <stdio.h>

int main( )
{
	int a, b, c, count=0;
	for ( a = 0 ; a <= 20 ; a++ )
	{
		for ( b = 0 ; b <= 33 ; b++ )
		{
			for ( c = 0 ; c <= 100 ; c++)
			{
				if ( a + b + c == 100 && 15 * a + 9 * b + c == 300 )
				{
					printf( "%d, %d, %d\n", a, b, c );
				}
				count++;
			}
		}
	}
	printf("count = %d\n",count);
	return 0;
}
