/* li04_09_break.c: break示例 */
#include <stdio.h>

int main( )
{
	int  i, n;
	for ( i = 1 ; i <= 5 ; i++ )
	{
		printf( "Enter n : " );
		scanf( "%d", &n );
		if ( n < 0 )
			break;
		printf( "n = %d\n", n );
	}
	printf( "The end.\n" );
	return 0;
}
