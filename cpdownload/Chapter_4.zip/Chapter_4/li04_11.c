/* li04_11.c: 循环嵌套示例：等腰梯形 */
#include <stdio.h>

int main( )
{
	int i, j;
	for ( i = 1 ; i <= 4 ; i++ )				/* 外层循环：控制行数 */
	{
		for ( j = 1 ; j <= 4-i ; j++ )			/* 内层循环：控制空格数 */
		{
			printf( " " );						/* 输出空格 */
		}
		for ( j = 1 ; j <= 2*i+1 ; j++ )		/* 内层循环：控制星号数 */
		{
			printf( "*" );						/* 输出星号 */
		}
		printf( "\n" );							/* 输出回车 */
	}
	return 0;
}
