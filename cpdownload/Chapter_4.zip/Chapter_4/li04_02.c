/* li04_02.c: if~else示例：输出年长者年龄 */
#include <stdio.h>

int main( )
{
	int age1, age2;
	printf( "Enter age of two persons : ");
	scanf( "%d%d", &age1, &age2);
	if ( age1 >= age2 )				/* age1较大 */
	{
		printf( "the older age is %d\n", age1 );
	}
	else							/* age2较大 */
	{
		printf( "the older age is %d\n", age2 );
	}	
	return 0;
}
