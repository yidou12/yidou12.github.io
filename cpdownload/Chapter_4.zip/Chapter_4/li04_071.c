/* li04_07.c: do~while语句示例：求阶乘 */
#include <stdio.h>

int main( )
{
	int n, i;
	double fac;
	do{
		printf ( "Enter a positive integer : " );
		scanf( "%d", &n );
	}while (n<0 || n>s170));
	
	i = 1;
	fac = 1;
	
	do
	{
		fac *= i;
		i++;
	 
	} while ( i <= n );	
	
	printf ( "%d!= %.0lf\n", n, fac );
	return 0;
}
