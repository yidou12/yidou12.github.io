/* li04_08.c: for语句示例：数列求和 */
#include <stdio.h>
#define N 1000
int main( )
{
	int i, sign;
	double item, sum;	
	
	sum = 0;								/* 初值置为0 */
	sign = 1;
	
	for ( i = 1 ; i <= N ; i++ )
	{
		item = sign /  ( 2.0 * i - 1 );		/* 计算每一次的累加项item */
		sum += item;						/* 将累加项item加到总和sum上 */
		sign = -sign;						/* 计算下一个累加项的符号sign */
	}

	printf( "sum = %f\n", sum );
	return 0;
}
