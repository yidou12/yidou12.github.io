#include <stdio.h>
char passwd[]="NJUPT";        /* 设定的密码 */
							  /*	函数功能：    判断密码与预设密码是否一致
							  函数入口参数：字符指针，指向用户输入的密码
							  函数返回值：  整型，表示密码正确与否，1正确，0错误
                                                          */
int check(char *ps)
{
    int i=0;
    int flag=1;                     /* 设定标志位 */
    for ( ; *ps!='\0'&&flag ; ps++)     /* 字符串结束标志的应用 */
	{
		if (*ps>='a' && *ps<='z')
			*ps=*ps-32;           /* 解密规则 如果输入的是小写字母-32转成对应的大写字母 */ 
        if (*ps!=passwd[i])        /* 只要有一个字符不吻合，flag=0，终止循环 */
            flag=0;
        else
            i++;
    }
	return flag;
}
int main()
{
    char str[10];
	int i=0;
    printf("Input your password:\n");
    while( (str[i]=getchar() ) != '#')      /* 逐字符读入，'#'作为结束标志 */
    {
        i++;
    }
    str[i]='\0';                        /* 增加字符串结束标志 */
    if (check(str))
		printf("Pass!\n");
    else
        printf("Error!\n\a\a\a");          /* 发出警报声 */
    return 0;
}
