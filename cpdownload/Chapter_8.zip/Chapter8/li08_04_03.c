//
//  li08_04_03.c
//  chapter8
//
//  Created by Yi Dou on 2022/11/28.
//

#include <stdio.h>
//#include <string.h>
  
char *strcat(char *strDest,const char *strScr)
{
       char * address = strDest;
       
       while(*strDest)
       {
              strDest++;
       }
       while(*strDest++ = *strScr++)
       {
              NULL;
       }
       return address;
}


int main()  {
    char str1[100] = "hello";
    char str2[100] = "world";
    strcat(str1,str2);
 
    printf("str1 = %s\n",str1);
    printf("str2 = %s\n",str2);
 
    //int len = strlen(str1);
   // printf("len的长度:%d\n",len);
    
    return 0;
}

