/* li08_01.c: 字符统计示例*/
#include <stdio.h>	
int main()
{
     int  character=0,digit=0,other=0;  
/* 设置统计变量并初始化为0 */
     char *p="Hello!",s[20];
     printf("%s\n",p);
     p=s;                      /* 字符指针p指向字符数组s */
     printf("input string:\n");
     scanf("%s",s);                  /* 从键盘输入字符串放在s数组中 */
    
      /* printf("'0'=%d,'9'=%d\n",'0','9');
     printf("'A'=%d,'Z'=%d\n",'A','Z');
     printf("'a'=%d,'z'=%d\n",'a','z'); 
     printf("-------------------------------------------------\n"); */
     while (*p!='\0')             /* 判断字符串是否结束 */                       
     {                                                            printf("'*p'='%c',=%d\n",*p,*p);
         if ( ('A'<=*p && *p<='Z') || ('a'<=*p && *p<='z'))
                        ++character;
           else  if((*p<='9')&&(*p>='0'))                                                      
                        ++digit;
    	    else                            
                        ++other;
	        p++;         /* 指针移动，指向字符串的下一个字符 */                                                           
	  }
     printf("-------------------------------------------------\n");
	 printf(" character:%d\n digit:%d\n other: %d\n",character,digit,other);              
     return 0;
}
