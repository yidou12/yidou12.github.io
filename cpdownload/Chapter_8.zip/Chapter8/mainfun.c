#include <stdio.h>
int main(int argc,char *argv[]){
  int i ;
    for(i=1;i<argc;i++)
        printf("%8s",argv[i]);  //%s表示输出char * 的变量
    printf("\n");
return 0;
}
