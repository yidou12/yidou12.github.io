/* li08_11.c 字符串综合应用 */
#include<stdio.h>
#include <string.h>
#define SIZE 100         /* 最多可存储的单词数目 */
int addword(char p[][20],int n);
int findword(char p[][20],int n, char *f);
int delword(char p[][20],int n,char *f);
void display(char p[][20],int n);
void menu();			
int main()
{
   	char myword[SIZE][20];
   	char word[20];
    char choice;
    int count=0;          /* 初始单词数目为0 */
    int pos=-1;            /* 表示单词在单词本中的位置，-1表示不在单词本中 */
   	do {
	   	menu();
	   	printf("Please input your choice: ");
	   	scanf("%c",&choice);
	   	getchar();       /* 去掉多余的回车字符 */
	   	switch(choice)
	   	{
			case '1':
		        count=addword(myword,count); 	/* 输入单词，并返回当前单词数目 */
				break;
	    		case '2':
	    		        printf("Please input what you are find:");
	    		        gets(word);
	    		        pos=findword(myword,count,word);/* 查找单词在单词本中的位置 */
	    		        if (pos!=-1)
                            printf("It's the %d word\n",pos+1);
                        else
                            printf("It's not in myword list!\n");
			    		break;
    	  		case '3':
                        printf("Please input what you want to delete:");
	    		        gets(word);
                        count=delword(myword,count,word);
			    		break;
                case '4':   display(myword,count);		/* 显示所有单词 */
				    	break;
            	case '0':  choice=0; break;
                default:
			    		printf("Error input,please input your choice again!\n");
            }
   	}while (choice);
   	return 0;
}

void menu( )
{
		printf("                    -------- 1. add word --------\n");
	  	printf("                    -------- 2. search word --------\n");
	  	printf("                    -------- 3. delete word --------\n");
	  	printf("                    -------- 4. show word --------\n");
	  	printf("                    -------- 0. exit --------\n");
	  	return;
}

int addword(char p[][20],int n)
{
     int i,j;
     int pos=-1;
     char flag='y';                          /* 是否继续需要输入单词的标志 */
     char tmp[20];
     while (flag=='y'||flag=='Y')
    {
         if (n==SIZE)
        {
              printf("Word list is full\n");     /* 单词表已满，不能再增加 */
              break;
        }
        else
        {
              printf("Input your word:");
              gets(tmp);
              pos=findword(p,n,tmp);         /* 判断待增加的单词是否已经存在 */
              if (pos!=-1)
              {
                     printf("the word is  exit!\n");
                     break;
              }
              else
              {
                     if(n)        /* 如果单词本中已有单词，需要按字典顺序插入单词 */
                    {
                           for (i=0;i<n&&strcmp(tmp,p[i])>0;i++);
/* 查找待插入的位置i，循环停止时的i就是 */
                           for (j=n;j>i;j--)    /* 用递减循环移位，使i下标元素可被覆盖 */
                                strcpy(p[j],p[j-1]);
                           strcpy(p[i],tmp);  /* 数组的i下标元素值为插入新增单词*/
                           n++;
                    }
                    else        /* 插入第一个单词 */
                    {
                        strcpy(p[0],tmp);
                         n=1;
                     }
              }
              printf("Another word?(y/n):");
              scanf("%c",&flag);
              getchar();       /* 去掉多余的回车字符 */
         }
    }
    return n;
}
int findword(char p[][20],int n, char *f)
{
        int i;
        int pos=-1;
        for(i=0;i<n;i++)
        {
            if(!strcmp(p[i],f))     /* 单词本中有待查单词 */
            {
                pos=i;
                break;
            }
        }
        return pos;
}
int delword(char p[][20],int n,char *f)
{
        int i;
        int pos=-1;
        pos=findword(p,n,f);              	/* 查找单词在单词本中的位置 */
        if (pos==-1)
            printf("It's not in myword list!\n");
        else
       {
            for(i=pos;i<n-1;i++)
           {
                strcpy(p[i],p[i+1]);
           }
           n=n-1;
       }
       return n;
}
void display(char p[][20],int n)
{
    int i;
    if (n)
    {
         for(i=0;i<n;i++)
         puts(p[i]);
    }
   else
        printf("There is no word in myword list!\n");
}
