#include<stdio.h>
/* void printAll(char (*a)[7])
{
    int i,j;
    for(i=0;i<5;i++)
    {
        for(j=0;j<7;j++)
            printf("%c",*(a[i]+j));
        printf("\n");
    }
}*/

int main( )
{
	  char a[5][7];
      int i;
      printf("Please input:\n");
      for(i=0;i<5;i++)
      gets(a[i]);		/* a[i]是指向字符串的指针 */
      printf("-------------------------------------------------\n");
	  for(i=0;i<5;i++)
      puts(a[i]);    /* a[i]是指向字符串的指针 */
      printf("-------------------------------------------------\n");
     // printAll(a);
	  return 0;
}
