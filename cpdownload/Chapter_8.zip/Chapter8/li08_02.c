/* li08_02.c: 字符数组示例 */
#include<stdio.h>
int main()
{
	char ch1[]={'H','e','l','l','o',' ','w','o','r','l','d','!','\0'};
    char ch2[]={"Hello world!"};
    
	printf("%s",ch1);
    printf("\n");
    
	printf("%s",ch2);
    printf("\n");
	return 0;
}
