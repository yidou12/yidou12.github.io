//
//  li08_04_01.c
//  chapter8
//
//  Created by Yi Dou on 2022/11/28.
//
#include <stdio.h>
//#include <string.h>
int strcmp(const char *s1, const char *s2)
{
    while(*s1 == *s2)
    {
        if(*s2 == '\0')
            return 0;
        s1++;
        s2++;
    }
    return (unsigned char)*s1 - (unsigned char)*s2;
}


int main()
{
    char *s1="Hello,Programmers!";
    char *s2="Hello,programmers!";
    int r;
    r = strcmp(s1,s2);
    if(!r)
        printf("s1 and s2 are identical");
    else if(r<0)
        printf("s1 less than s2");
    else
        printf("s1 greater than s2");
    getchar();
    return 0;
}
