#include<stdio.h>
#include<string.h>
/* void strupr(char* s)
{
    while (*s != '\0')
    {
        if (*s >= 'a' && *s <= 'z')
            *s -= 32;
        s++;
    }
}*/
 
int main( )
{
	char str[20]="Programming";
	char cstr[20];
	char tmp[20];
	int i;
  

	printf("Input a string:\n");
	gets(cstr);
	printf("-------------------------------------------------\n");
	printf("str=");
	puts(str);
	printf("cstr=");
	puts(cstr);
	printf("-------------------------------------------------\n");
    printf("%d\n",strcmp(str,cstr));
	if (strcmp(str,cstr)>0)              /* 字符串比较，小的字符串放在str中 */
	{
		strcpy(tmp,str);
		strcpy(str,cstr);
		strcpy(cstr,tmp);
	}

	printf("str=");
	puts(str);
	printf("cstr=");
	puts(cstr);
	printf("-------------------------------------------------\n");
	strcat(cstr,"**");                 /* 在cstr后加上字符** */
	i=strlen(cstr);
	if(i+strlen(str)<20)
        {
		strcat(cstr,str);               /* 将str连接到cstr后 */
		puts(cstr);
	}
        else
        printf("Strcat can't be executed!\n");
	printf("-------------------------------------------------\n");
    strupr(cstr);
	puts(cstr);
	return 0;
}
