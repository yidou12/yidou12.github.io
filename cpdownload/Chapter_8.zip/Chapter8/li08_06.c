/* li08_06.c */
#include<stdio.h>
#include<string.h>
/*	函数功能：    查询一个句子中子串出现的次数
	函数入口参数：
                  2个指向常量的字符指针，分别指向句子和待查询的子串
	函数返回值：  整型，表示子串出现的次数
*/
int search(const char *ps, const char *pf) /* ps指向的句子，pf指向的待查询子串 */
{
    int count=0,i=0;
    char dest[20];           /* 存储句子中的一个单词 */
   	while(*ps)             /* 判断字符串是否结束 */
	{
		i=0;
		while((*ps>='a'&&*ps<='z')||(*ps>='A'&&*ps<='Z')) /* 一个一个单词的字母提取出来，碰到空格就算一个单词提取结束 */
		{
			dest[i++]=*ps++;
		}                    /* 这个循环用于分词，每个词存在数组dest中 */
		dest[i]='\0';
		ps++;                /* 指向句子的下一个字符 */
		if(strcmp(dest,pf)==0)  /* 比较是否是待统计的单词 */
			count++;
    }
    return count;
}

int main()
{
	char source[200];
    char key[15];
    puts("Input the source sentence:");
	gets(source);
	puts("Input the key word:");
	gets(key);

	printf("There are %d key words in this sentence.\n",search(source,key));
	return 0;
}
