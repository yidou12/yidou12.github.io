//
//  li08_04_02.c
//  chapter8
//
//  Created by Yi Dou on 2022/11/28.
//

#include <stdio.h>
//#include <string.h>
char *strcpy(char *dst, const char *src)
{
    int i = 0;
    while (src[i] != '\0')
    {
        dst[i] = src[i];
        puts(dst);
        i++;
    }
     
    dst[i]='\0';
    puts(dst);
                          //当strScr字符串长度小于原strDest字符串长度
    return dst ;
}
int main()
{
        char a[80]="ABCD";
        char b[80]="ddssssfff";
        //puts(b);
        printf("The copy is:\n");
        strcpy(b, a);
        
       // puts(b);
        return 0;

    
}
