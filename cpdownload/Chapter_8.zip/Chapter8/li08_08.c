/* 字符串排序的方法二：用二维字符数组实现 */
#include <stdio.h>
#include <string.h>
/*	函数功能：    对多个字符串排序
	函数入口参数：
                  列长度为10的行指针，用来接受实参传递过来的二维字符数组
	函数返回值：  无
*/
	void sort(char (*str)[10] , int n)
	{
	    char temp[20];
	    int  i, j , k;
	    for (i=0;i<n-1;i++)
	    {
	        k=i;
            for (j=i+1;j<n;j++){
                if (strcmp(str[k],str[j])>0)        /* 比较字符串大小 */
                    k=j;
            }
           
	        if (k!= i)                       /* 交换字符串内容 */
	        {
	            strcpy(temp,str[i]);
	            strcpy(str[i],str[k]);
	            strcpy(str[k],temp);
	        }
			//puts(str[0]);
            //puts(str[1]);
            //puts(str[2]);
            //puts(str[3]);
            //puts(" ");
	    }
	 }
	int main()
	{
	    char string[][10]={"FORTRAN","PASCAL","BASIC","C"};
	                       /* 二维字符数组存储4个字符串 */
	    int  i , nNum=4;
	    sort(string , nNum);
	    for (i=0;i<nNum;i++)
	        printf("%s\n" , string[i]);  /* string[i]表示指针数组中第i个字符串的首地址 */
        return 0;
	}
