//
//  biao7_3.c
//  chapter7
//
//  Created by Yi Dou on 2022/11/13.
//

#include <stdio.h>
void  SwapByValue(int, int); /* 值形参 */
int main()
{
    int a=3,b=4;
    printf("a=%d, b=%d\n", a, b);
    SwapByValue(a, b);
    printf("a=%d, b=%d\n", a, b);
    return  0;
}
void  SwapByValue(int x, int y)
{
    int tmp;
    tmp = x;
    x = y;
    y = tmp;
    printf("x=%d, y=%d\n", x, y);
}
