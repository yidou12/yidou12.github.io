/* li7_01.c: 定义指针变量示例 */
#include <stdio.h>
int main()
{
int count=10;
int *p=&count;                         /* 定义指针变量并初始化 */
printf("\t address\t\tvalue\n");
printf("count:\t%10p\t%10d\n",&count,count); /* 变量count的地址和值 */       
printf(" p:\t%10p\t%10p\n",&p,p);        /* 指针变量p的地址和值 */       
printf(" \n change count: \n");
count=20;
printf("p=%10p\t*p=%10d\n ",p,*p);                                       
/* 用指针变量p访问变量count的地址和值 */
    return 0;
}       
