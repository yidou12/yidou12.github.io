/* li7_05.c: 指针访问二维数组元素示例 */
#include<stdio.h>
int main()
{
	int a[3][2]={1,2,3,4,5,6};
	int i;
	int *p=&a[0][0];                                                   
	for(i=0;i<6;i++)
	{
		printf("%p\t%d\n",p+i,*(p+i));     /*通过指针访问各个元素*/                    
	}
 	return 0;
}
