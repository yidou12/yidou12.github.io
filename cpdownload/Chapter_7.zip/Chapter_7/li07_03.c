/* li7_03.c: 指针访问数组元素示例 */
#include <stdio.h>
int main()
{
double score[5]={90.5,91.0,92.0,93.5,94.0};
double *p=score;
    /* 将数组名score赋值给指针变量p，指针p指向数组score的首位置，p可以当做数组名使用 */
    int i;
    double sum=0.0;
    printf("The array is:\n");
    for (i=0;i<5;i++)
        printf("score[%d]:\t%f\t%4.2f\n",i,score[i],*(p+i));   /*p在不移动的情况下，相当于数组名，指针p本身不移动不修改，移动下标访问*/
    for(p=score;p<score+5;p++)
    /*  每一次循环之后，p向下移动一个位置，移动指针(指针改变)，p每指向一个新元素的时候，*p代表了该元素值  */
    
        sum += *p; 
    printf("the average of score is:%4.2f\n",sum/5);
    return 0;
}
