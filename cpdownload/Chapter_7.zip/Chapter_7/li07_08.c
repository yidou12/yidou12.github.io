/* li7_08.c: 指针作为形参示例 */
#include<stdio.h>
/* 函数功能：计算两个数的和与差
函数参数：前两个形参是两个数，第3个形参是和的指针，第4个形参是差的指针
函数返回值：无返回值,返回类型为void 
*/
void calculate(int x, int y,int * sum,int * diff)
{
	*sum=x+y;
    *diff=x-y;
}
int main( )
{
    int a=3,b=4;
    int sum, diff;
    calculate(a, b, &sum, &diff);
    printf("%d + %d = %d\n", a ,b, sum);
    printf("%d - %d = %d\n", a, b, diff);
    return 0;
}
