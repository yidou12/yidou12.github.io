/* li7_09.c: 函数返回指针示例 */
#include <stdio.h>
    int *smaller(int *x, int *y);    /* 函数功能：求两个数中的较小值，返回指针 */       
    int main()
	{
	    int a, b, *s;
	    printf("Enter two integer values:\n");
	    scanf("%d%d", &a, &b);
        //printf("\n%p\t%p\n",&a,&b);
	    s= smaller(&a, &b);      /* 函数返回为地址值，给指针变量赋值 */     
	    printf("The smaller value is %d.\n", *s);
	    return 0;
	}
/* 函数功能：找出两个数中的较小数
函数参数：两个形式参数分别是两个数的指针
函数返回值：较小数的指针
*/
	int *smaller(int *x, int *y)
	{
	    if (*y< *x)
	        return y;
	    return x;
	}
