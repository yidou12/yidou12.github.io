/* li7_07.c: 指针数组访问二维数组元素示例 */
#include<stdio.h>
int main()
{
	int a[3][2]={1,2,3,4,5,6};
	int i,j;
	int *p[3];                    
/*定义长度为3的指针数组*/           
   for(i=0;i<3;i++)
  {
    p[i]=a[i];                     /* 把i行0列地址赋给p[i],一级指针只能获得列地址 */
    for(j=0;j<2;j++)  /* 用第二次循环控制i行的各列 */
     printf("%p\t%d\n", p[i]+j, *(p[i]+j));   /* 后面两项都表示元素a[i][j] */
   } 	
return 0;
}
