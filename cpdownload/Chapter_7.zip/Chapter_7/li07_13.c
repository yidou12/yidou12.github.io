/* li7_13.c: 矩阵运算*/
#include <stdio.h>
#define COL   3
#define ROW  3
/* 函数功能：输出数组元素
函数参数：形式参数是一个行指针 
函数返回值：无返回值
*/
void Output(int (*pa)[COL])                                                 
{
		int i, j;
		for(i=0; i<ROW; i++)
        {  
           for (j=0; j<COL; j++)		  
		     printf("%d\t",  pa[i][j]);  // *(*(pa+i)+j) *(pa[i]+j)
		   printf("\n");
         }
}
/* 函数功能：计算数组对角线元素之和
函数参数：形式参数是一个行指针 
函数返回值：返回对角线元素和
*/
int Sum(int (*pa)[COL])                  /* 计算数组对角线元素之和*/        
{		
        int i, j;
		int sum=0; 
        for(i=0; i<ROW; i++)	  
		     sum+=pa[i][i];     /*对角线元素进行累加  *(*(pa+i)+i) *(pa[i]+i)*/
		return sum;
}
int main()
{	
    int a[ROW][COL]={{5,6,7},{10,11,12},{15,16,17}};
	Output(a);                /*调用时用行指针a初始化行指针变量pa*/   
	printf("\nThe sum of diagonal is: %d\n", Sum(a));                         
	return 0;
}
