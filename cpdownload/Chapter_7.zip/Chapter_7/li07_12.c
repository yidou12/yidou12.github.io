/* li7_12.c: 选择法排序 */
#include <stdio.h>
/* 函数功能：输入数组元素
函数参数：第1个形式参数是指向数组的指针，第2个是数组元素个数
函数返回值：无返回值 
*/
void Input(int *pa,int n)   
{
    int i;
    printf("Please input %d elements:\n",n);
	for (i=0;i<n;i++)   /* 用for语句控制输入n个元素 */
		scanf("%d",pa+i);   /* 是地址，pa当做一维数组名使用，采用移动下标法，&pa[i]等效 */
}
/* 函数功能：输出排序后的数组元素
函数参数：第一个形式参数是指向数组的指针，第二个是数组元素个数
函数返回值：无返回值
*/
void Output(const int *pa,int n)     /* 输出数组元素 保护型措施 const 限制通过pa指针修改数组元素的值 只可以对元素做访问性操作 只需要原样显示不应该做任何修改 */
{
    int i;
    for (i=0;i<n;i++)             /* 用for语句控制输出n个初始元素 */
        printf("%5d",*(pa+i));
    printf("\n");
}
/* 函数功能：对n个数组元素排序
函数参数：第1个形式参数是指向数组的指针，第2个是数组元素个数
函数返回值：无返回值
*/
void sort(int *pa, int n)                    
{
    int index, i, k, temp; /* index记录每趟最小元素的下标 k控制趟数 i控制二层循环 temp作为元素交换时的中间变量 */
    for (k=0;k<n-1;k++)       /* k控制排序的趟数，以0到n-2表示所有趟 */
	{
		index=k ;            /* 本趟最小位置存于index,开始时为k,默认k下标的元素最小 */
        for (i=k+1;i<n;i++)    {/* 通过内层循环找出本趟真正的最小元素 */
			if (pa[i]<pa[index])     /* 将本趟最小元素的下标赋给index */
				index=i;
            }
		if (index!=k)           /* 如果本趟最小元素没有到位 */
        { 
            temp=pa[index];    /* 则通过交换使本趟最小元素到k下标处 */
			pa[index]=pa[k];
			pa[k]=temp;
		}
        Output(pa,n);
	}
}

int main()
{	int a[10],n;                          /* 定义数组，n控制元素个数 */
	do                                 /* 保证读入的n满足1≤n≤10 */
	{	printf("Please input n(1<=n<=10):\n");
		scanf("%d",&n);
	}while (n<1||n>10);
    
	Input(a,n);                          /* 调用函数，完成输入 */
	printf("The original array is:\n");
    Output(a,n);                        /* 调用函数，输出原始数组 */
	 sort(a,n);                           /* 调用函数，完成排序 */
     printf("The sorted array is:\n");
	 Output(a,n);                        /* 调用函数，输出排序后的数组 */
	 return 0;
}
