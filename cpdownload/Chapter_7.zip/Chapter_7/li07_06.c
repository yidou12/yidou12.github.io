/* li7_06.c: 行指针变量访问二维数组元素示例 */
#include<stdio.h>
int main()
{
	int a[3][2]={1,2,3,4,5,6};
	int i,j;
	int (*p)[2];                                                        
    p=a;                                                              
	for(i=0;i<3;i++)
   {  for(j=0;j<2;j++)
		printf("%p\t%d\n", p[i]+j, p[i][j]);     /*通过行指针访问各个元素*/            
	}
 	return 0;
}
