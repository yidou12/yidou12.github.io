/* li7_04.c: 二维数组地址和运算示例 */
#include<stdio.h>
int main()
{
	int a[3][2];
	printf("%p\t%p\n", a, a+1);   /*二维数组名为行地址*/
	printf("%p\t%p\n", a[0], a[0]+1); /*二维数组的列地址*/
	printf("%p\t%p\n", &a[0], &a[0]+1); /*二维数组的行地址*/
	printf("%p\t%p\n", &a[0][0], &a[0][0]+1);  /*二维数组的列地址*/
	return 0;
}
