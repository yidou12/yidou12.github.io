/* li7_01.c: 定义指针变量示例 */
#include <stdio.h>
int main()
{
int count=10;
int *p=&count;                         /* 定义指针变量并初始化 */
    
printf("\t  address\t\tvalue\n");
printf("&count=%-10p, count=%-10d\n",&count,count); /* 变量count的地址和值 */
printf("&p=%-10p, p=%-14p\n",&p,p);        /* 指针变量p的地址和值 */

printf("\n****after count=20, address and value are: \n");
count=20;
printf("&count=%-10p, count=%-10d\n",&count,count); /* 变量count的地址和值 */
printf("p=%-10p, *p=%-14d\n",p,*p);        /* 用指针变量p访问变量count的地址和值 */
                                    
printf("\n****after *p=1000, address and value are: \n");
*p=1000;// *p=1000 == count=1000
printf("&count=%-10p, count=%-10d\n",&count,count); /* 变量count的地址和值 */
printf("p=%-10p, *p=%-14d\n",p,*p);        /* 用指针变量p访问变量count的地址和值 */
                                    


    return 0;
}       
