//
//  li07_05_01.c
//  chapter7
//
//  Created by Yi Dou on 2022/11/9.
//

/* li7_05_01.c: 指针访问二维数组元素示例 */
#include<stdio.h>
int main()
{
    int a[3][2]={1,2,3,4,5,6};
    int i;
    int *p=&a[0][0];  /* 可以换成 *a, a[0] */
    printf("方法1：指针p固定不动，当做数组名来使用，移动下标\n");
    for(i=0;i<6;i++)
    {
        printf("%p\t%d\n",p+i,*(p+i));     /*通过指针访问各个元素*/
    }
    printf("方法2：指针p不断移动，用间接访问*p来访问所有的元素\n");
    for(p=*a;p<*a+6;p++)
    {
        printf("%p\t%d\n",p,*p);     /*通过指针访问各个元素*/
    }
    printf("以3*2矩阵方式显示所有元素值\n");
    p=*a;
    for(i=0;i<6;i++)
    {
        printf("%5d",p[i]);
        if((i+1)%2==0) printf("\n");
     }
    
     return 0;
}

