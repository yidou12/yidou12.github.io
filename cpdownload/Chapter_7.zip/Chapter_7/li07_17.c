/* li7_17.c: 函数指针示例*/
#include <stdio.h>
	int larger(int x, int y);
	int smaller(int x, int y);
	int main()
	{
	  int a, b;
      int (*pf)();                       /*定义无参数的函数指针*/        
	  printf("Enter two integer values:\n");
	  scanf("%d %d", &a, &b);
      pf=larger;                        /*pf指向函数larger*/            
      printf("The larger value is %d. \n",(*pf)(a,b));  /*相当于调用larger(a,b)*/  
      pf=smaller;                     /*pf指向函数smaller*/            
      printf("The smaller value is %d.\n",(*pf)(a,b)); /*相当于调用smaller(a,b)*/  
	  return 0;
	}
/*函数功能：找出两个数中的较大数
函数参数：两个形式参数分别是两个数 
函数返回值：较大数
*/
	int larger(int x, int y)
	{
	    if (y > x)
	        return y;
	    return x;
	}
/*函数功能：找出两个数中的较小数
函数参数：两个形式参数分别是两个数 
函数返回值：较小数
*/
	int smaller(int x, int y)
	{
	    if (y<x)
	        return y;
	    return x;
	}
