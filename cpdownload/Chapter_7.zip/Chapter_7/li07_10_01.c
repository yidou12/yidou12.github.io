/* li7_10.c: 批量数据的筛查 */
#include <stdio.h>
#include <math.h>
#define NUM  15          /* 待处理数组的长度 */
#define  T   5           /* 偏移阈值 */
/* 函数功能：找出异常数据并输出
函数参数：形式参数是一个指针
函数返回值：无返回值 
*/
int Find (float *p, float *q)
{
    float average,sum=0;
    int i,count=0;
    for(i=0; i<NUM; i++)
        sum+=*(p+i);
     average=sum/NUM;
     for(i=0; i<NUM; i++)
         {
       if(fabs(*(p+i)-average) > T)
        {
		  *(q+count)=*(p+i);
          count++;
         }
      }
      
    return count;
}
int main( )
{ float array[NUM]={17.5, 20.1, 23.1, 15, 17, 26, 30, 12, 18.2, 19.6, 10, 16.7, 17.7, 16.5, 20};
  float outliers[NUM]={0.0};
  int i = 0;
  int count = Find(array, outliers);
 
  for( ; i< count; i++)
	   printf("%5.2f\t", *(outliers+i));
  printf("\n The number of abnormal data is : %d\n", count);/* 筛查并输出异常数据 */
    return 0;
}
