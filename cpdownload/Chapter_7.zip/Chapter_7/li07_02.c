/* li7_02.c: 数组名间接访问数组元素示例 */
#include <stdio.h>
int main()
{
  double score[5]={90.5,91.0,92.0,93.5,94.0};
  int i;
  double sum=0.0;                          /* 求和变量初始化 */
  printf("The address of the array:%10p\n",score);
  printf("The address and value of each element:\n");
  
  printf("The address (&score[i]) and value (score[i]) of each element:\n");
  for (i=0;i<5;i++)
    printf("score[%d]:\t%p\t%4.2f\n",i,&score[i],score[i]); /* 输出元素地址和值 */
    
  printf("The address (score + i) and value (*(score + i)) of each element:\n");
  for (i=0;i<5;i++)
    printf("score[%d]:\t%p\t%4.2f\n",i,score+i,*(score+i)); /* 输出元素地址和值  *(score+i) = score[i]
                         score + i =&score[i] */
  for(i=0;i<5;i++)
    sum += *(score+i);       /* 通过数组名间接访问数组元素的值 */         
  printf("the average of score is:%4.2f\n",sum/5);
  return 0;
}
