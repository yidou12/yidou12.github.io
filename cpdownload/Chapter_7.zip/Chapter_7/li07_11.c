/* li7_11.c: 进制转换 */
#include<stdio.h>
int main()
{
     int r[16];                  /* 定义数组存放转换后的二进制各位数值 */  
     int *p=r;                  /* 定义指针指向数组 */                        
     int m, i=0;                     /* 存放待转换的整数 */
     printf("Input an integer which belong to 0~65535\n");
     do
     {
         scanf("%d",&m);        /* 输入待转换的整数 */
     } while (m<0 || m>65535);
    
     while(m!=0)
     {
         *p=m%2;
          m=m/2;
          printf("r[%d] address is: %p\t%d\n",i++,p,*p);
          p++;
          
      }
      printf("\nThe binary is:\n");
      p--;                          /* 指向最后得到的那个余数 */
      i--;
      for ( ; p>=r ; p--)               /* 逆序输出得到转换后的二进制值 */
         //printf("%d",*p);
         printf("r[%d] address is: %p\t%d\n",i--,p,*p);
     printf("\n");
     return 0;
}
