/* li7_04.c: 二维数组地址和运算示例 */
#include<stdio.h>
int main()
{
    int a[3][2]={1,2,3,4,5,6};
    printf("二维数组中所有元素的地址\n");
    printf("%p\t%p\n", &a[0][0], &a[0][1]);
    printf("%p\t%p\n", &a[1][0], &a[1][1]);
    printf("%p\t%p\n\n", &a[2][0], &a[2][1]);
    
    printf("二维数组中的行地址\n");
    printf("%p\t%p\t%p\n", a, a+1,a+2);   /*二维数组名为行地址*/
    printf("%p\t%p\t%p\n\n", &a[0], &a[1],&a[2]); /*二维数组的行地址*/
    
    printf("二维数组中 i=0 的列地址\n");
    printf("%p\t%p\n", &a[0][0], a[0]);//元素的地址都是列地址
    printf("%p\t%p\n\n", *a, *a+1);  // *(a+0)+0 = *a = a[0]
    
    printf("二维数组中a[1][0]和a[1][1]的列地址\n");
    printf("%p\t%p\n", &a[1][0], &a[1][0]+1);  /*二维数组的列地址*/
    printf("%p\t%p\n", a[1], a[1]+1); /*二维数组的列地址*/
    printf("%p\t%p\n\n", *(a+1), *(a+1)+1);
    
    printf("行地址、列地址分别用*运算符\n");
    printf("%p\t%p\n", a, a[0]); /* a是0行的行地址，a[0]是0行0列的地址 */
    printf("%p\t%d\n", *a, *a[0]); /* *a是0行0列的地址，*a[0]是0行0列元素值 */
    
    printf("二维数组中元素的表达\n");
    printf("%d\t%d\t%d\n", **a, *a[0],a[0][0]); /* a是行地址，a[0]是列地址 */
    printf("%d\t%d\t%d\n", *(*(a+2)+1), *(a[2]+1),a[2][1]);
    
    return 0;
}

