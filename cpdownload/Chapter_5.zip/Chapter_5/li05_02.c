/* li5_2.c: totalCost函数定义示例 */
#include <stdio.h>
double totalCost (int n, double p);  /* 计算购买商品总额 */  
int main()
{
    double price, bill;   /* 单价、总额 */
	int number;        /* 购买数量 */
	printf( "Enter the number of items purchased: ");
	scanf("%d", &number);
	printf("Enter the price per item (RMB): ");
	scanf("%lf", &price);
	bill = totalCost(number, price);
	printf("The total cost of the items purchased is: %.1f RMB.\n", bill);
	return 0;
}
/* 函数功能：计算购买商品所需的总金额
函数参数：第1个形参为商品数量，第2个形参为商品单价
函数返回值：实型，返回总金额
*/
double totalCost (int n, double p)                                                     
{                                                                       
	const double DISCOUNT = 0.2;   /* 多件商品的折扣 */                           
        double total;                                                                
	if (n>1)                                                                         
		total = n*p*(1-DISCOUNT);                                           
	else                                                                      
		total = n*p;                                                           
	return total;                                                                        
}                                                                       