/* li05_10.c: 静态局部变量示例 */
#include<stdio.h> 
int fun(int n);             /* 函数功能：求n! */
int main() 
{     
	 int i;
	 for(i =1;i <=5;i++)    /* 依次求1!到5! */
		 printf("%d != %d\n" , i , fun(i));  
	 return 0;
}
/* 函数功能：采用静态局部变量求阶乘
函数参数： 整数n
函数返回值： n!
*/
int fun(int n)             /* 此题只求到5的阶乘，因此返回值可用int型 */
{     
	 static int f= 1;       /* 定义静态局部变量f */   
	 f=f*n;             /* f保存了(n-1)!的结果，本语句得到n! */
	 return f; 
}
