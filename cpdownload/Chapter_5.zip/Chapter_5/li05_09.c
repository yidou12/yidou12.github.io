/* li05_09.c: 全局变量示例 */
#include <stdio.h>
#include <math.h>
int count;       /* 定义全局变量count并自动初始化为0 */                              
int judgePrime(int n);   
int main()
{ 
     int i;
     printf("The primes between 2 to 100 : \n");
     for (i= 2; i< 100; i++)
     if (judgePrime(i))   /* 函数调用放在if表达式，i为质数则条件成立 */    
     {  
         printf("%d ", i);
         count++;                                                                              
     }
     printf("The total number of primes: %d\n", count);
     return 0;
}
/* 函数功能：判断质数函数
函数参数： 整数n
函数返回值： 1（是质数）或0（不是质数） 
*/
int judgePrime(int n)     
{
     int i ; 
     int judge=1;       /* judge存判断结果，未判断时默认为是质数 */ 
     if ( n==1 )        /* 1不是质数 */ 
       judge=0 ;
     {                                                                  
         int k = (int) sqrt ( n );    /* 在语句块内定义局部变量k */                            
	     for (i = 2; judge && i<=k ; i++)                                     
		 if (n % i == 0)                                                    
		     judge=0 ;                                                   
     }                                                                  
     return judge;
}
