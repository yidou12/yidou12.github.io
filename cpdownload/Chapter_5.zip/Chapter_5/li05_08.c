/* li05_08.c: 数值转换示例 */
#include <stdio.h>
void MultiBase(int n,int B);
int main( ) 
{    int n,B;
	 do
	 {	
         scanf("%d%d",&n,&B); 
	 }while (n<=0||B<=1||B>16);     /*读入的n为正整数，且B在2到16之间*/
	 printf("change result:\n"); 
	 MultiBase(n,B);             /*调用递归函数*/ 
	 printf("\n");
	 return 0;
}
/*函数功能： 数制转换，将十进制数转换为B进制数
函数参数： 十进制整数n和进制B
函数返回值：无返回值 
*/
void MultiBase(int n,int B)      
{	 int m; 
	 if(n)		                  /*n!=0时递归调用*/
	 {
	     MultiBase(n/B,B);          /*递归时第1个参数变化*/
	     m=n%B;                  /*求本层的余数*/
	     if(m<10)                  /*余数<10原样输出*/
	   	     printf("%d",m);
	     else     /*余数>=10输出字符，A代表10，其他字符依次递增*/
		     printf("%c",m+55); 
	 }	
}           
