 /* li05_05.c: 判断质数示例 */
#include<stdio.h>
#include<math.h> /* 程序中调用sqr函数 */
int judgePrime(int n);
int main()
{
	int m,prime; 
	scanf("%d",&m); 
	if ( m<=0 )
	{
		printf("error input!\n");
		return 0;
	}
	prime=judgePrime(m);            /* 函数调用返回值赋给变量prime */       
	if  ( prime)
		printf ( "%d is a prime!\n" , m ) ;/* 如果prime值为1*/
	else                           /* 如果prime值为0 */
		printf ("%d is not a prime!\n", m ) ;
	return 0 ;
} 

/* 函数功能： 判断一个整数是否为质数
  函数参数： int型的整数
  函数返回值： 1和0，1表示是质数，0表示不是质数
*/
int judgePrime(int n)
{
	int i,k ; 
	int judge=1;               /* judge存判断结果，未判断时默认为是质数 */
	if ( n==1 )                /* 1不是质数 */
		judge=0 ;
	k = (int) sqrt ( n );           /* k为判断n时需要的最大除数 */
	for (i = 2; judge && i<=k ; i++)  /* 除数的范围从2到k，若judge为0则终止 */
		if (n % i == 0)          /* 若n被某除数整除，则不是一个质数 */
			judge=0 ;
	return judge;	                                                         
}
