/* li05_11.c:函数调用示例 */
#include <stdio.h>
#include <math.h>
#define  PI  3.14159
double getArea(double radius);       /* 求圆面积 */                      
double getVolumeS (double radius);   /* 求球体积 */                           
double getVolumeC (double radius, double height); /* 求圆柱体积 */                   
int main( )
{
     double radius, height, areaOfCircle, volumeOfSphere, volumeOfCylinder;
     printf("Enter the radius of a circle, a sphere and the surface of a cylinder: ");
     scanf("%lf",&radius);
     printf("Enter the height of a cylinder: ");
     scanf("%lf",&height);
     if (radius<0)                 /* 保证输入的半径合法 */
	     radius=-radius;
     if (height<0)
	     height=-height;
     areaOfCircle = getArea(radius);          /* 调用getArea函数 */              
     volumeOfSphere = getVolumeS(radius);    /* 调用getVolumeS函数 */        
     volumeOfCylinder = getVolumeC(radius, height);  /* 调用getVolumeC函数 */                                         
     printf( "Area of circle = %lf \n", areaOfCircle);
     printf( "Volume of sphere = %lf \n", volumeOfSphere);
     printf( "Volume of cylinder = %lf \n", volumeOfCylinder);
     return 0;
}
/* 函数功能： 计算圆的面积
函数参数： 圆的半径（double型数据）
函数返回值： 圆的面积（double型数据）
*/
double getArea(double radius)      
{
     return (PI * pow(radius, 2));    /* 调用库函数pow */
}
/* 函数功能： 计算球的体积
函数参数： 球的半径（double型数据）
函数返回值： 球的体积（double型数据）
*/
double getVolumeS(double radius)    
{
     return ((4.0/3.0) * PI * pow(radius, 3));   /* 调用库函数pow */
}
/* 函数功能： 计算圆柱的体积
函数参数： 底半径（double型数据）和高（double型数据）
函数返回值： 圆柱的体积（double型数据）
*/
double getVolumeC(double radius, double height)    
{
     return getArea(radius) *height;   /* 调用函数getArea */
}
