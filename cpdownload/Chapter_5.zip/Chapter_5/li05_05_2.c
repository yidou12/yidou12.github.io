//
//  li05_05_1.c
//  chapter5
//
//  Created by Yi Dou on 2022/9/30.
//

#include <stdio.h>
void swap(int a, int b){
    int temp;
    temp = a;
    a = b;
    b = temp;
}
int main(){
    int a = 3, b = 5;
    swap(a, b);
    printf("a=%d, b=%d\n",a,b);
    return  0;
     
}
