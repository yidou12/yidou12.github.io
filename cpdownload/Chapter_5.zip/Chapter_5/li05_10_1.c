/* li05_10_1.c: 静态局部变量示例 */
#include <stdio.h>
int Square(int i)
{
	return  i * i;
}
int main()
{
	int j = 0;
	j = Square(j);
  	for( ; j<3; j++)
 	{
	 	static int i = 1;
	  	i += Square(i);
	  	printf("%d, ", i);
 	}
 	printf("\n%d\n", j);
}