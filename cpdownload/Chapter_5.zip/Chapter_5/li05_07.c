/* li05_07.c:递归函数示例 */
#include <stdio.h>
double Fact (int n);                                         
int main( )
{
	 int n;
	 double t;
	 printf("Please input n:\n");
	 scanf("%d",&n);
	 if (n<0)
		 n=-n;          /*如果n为负数则取反，保证了n大于等于0*/
	 t=Fact(n);
	 printf("%d!=%lf\n",n,t);
	 return 0;
}
/*函数功能： 实现求阶乘
函数参数： int型数n
函数返回值： n!的 double型结果
*/
double Fact( int n)                                                                  
{                                                                    
	 if (!n)             /*当n为0时返回1.0*/                                        
		 return (1.0);
     
	 return (n*Fact(n-1)); /*当n大于0时递归调用Fact函数*/                           
}                                                                    
