/* li05_06.c: drawLine函数调用示例 */
#include <stdio.h>                                   
void drawLine();
int main ()
{
	drawLine ();   /* 第一次调用drawLine 函数 */
	printf ("C is a beautiful language!\n");
	drawLine ();   /* 第二次调用drawLine 函数 */
	return 0;
}
/* drawLine函数定义示例 */
/* 函数功能：画一条固定长度的横线
函数参数：无
函数返回值：无
*/
void drawLine ( )       /* 画一条横线 */
{
	const int n=30;     /* 该值可以指定 */
	int i;              
	for (i=1; i<=n; i++)  /* 连续输出n个减号 */
		printf("-");
	printf("\n");       
	return;             /* 返回 */ 
}
