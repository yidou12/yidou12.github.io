//
//  labsorting.c
//  chapter6
//
//  Created by Yi Dou on 2022/10/31.
//
 
#include <stdio.h>
 
int main(){
    double temp, a[3]={0};
        printf("Enter three edges of a triangle:");
        scanf("%lf",&a[0]);
        scanf("%lf",&a[1]);
        scanf("%lf",&a[2]);
    
    if (a[0] <= 0 || a[1] <= 0 || &a[2]<= 0) {
        printf ( "Error input!\n" );
    }else{
        for(int i=0;i<2;i++)
            for(int j=2;j>i;j--)
            {
               if(a[j]<a[j-1])
               {
                   temp=a[j-1];
                   a[j-1]=a[j];
                   a[j]=temp;

               }
                printf("Three edges are %f, %f, %f\n", a[0], a[1], a[2]);
            }
         
        
    }
 
    return 0;
 
}


