/* 例9.1无参宏指令应用示例 */
#include<stdio.h>
#define PI 3.14159		/* 无参宏定义1，符号常量 */
#define ISPOSITIVE >0	/* 无参宏定义2 */
#define FORMAT	"Area=%f\n"    /* 无参宏定义3 */
#define ERRMSG  "Input error!\n" /* 无参宏定义4 */
int main( )  
{   
   double r;
 
   scanf("%lf", &r);  /* 输入圆的半径 */
   if(r ISPOSITIVE)   /* 若r>0则输出圆的面积，否则报错。 */
	   printf(FORMAT, PI*r*r);  /* "Area=%f\n"*/
   else
	   printf(ERRMSG); /* "Input error!\n" */
   return 0;
}

