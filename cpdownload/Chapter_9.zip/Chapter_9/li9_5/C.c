/* C.c */
#include<stdio.h>
extern int x;   /* 外部变量声明 */
void fc()
{   
   x++;
   printf("fc() is called, x=%d\n",x);
}
