/* A.c */
#include<stdio.h>
extern void fb();  /* 外部函数声明 */
extern void fc();  /* 外部函数声明 */
int x=0;      /* 全局变量定义 */
int main()
{   
   printf("x=%d\n",x);
   fb();
   fc();
   x++;
   printf("x=%d\n",x);
   return 0;
}
