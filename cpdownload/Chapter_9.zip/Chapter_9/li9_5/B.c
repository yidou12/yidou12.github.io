/* B.c */ 
#include<stdio.h>
extern int x;   /* 外部变量声明 */
void fb()
{   
   x++;
   printf("fb() is called, x=%d\n",x);
}
