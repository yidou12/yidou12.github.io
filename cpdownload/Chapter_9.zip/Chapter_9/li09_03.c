/* 例9.3	条件编译指令应用示例 */
#include<stdio.h>
#include<math.h>
#define DEBUG
int main()
{   
   double a, b, c;
   double s, area;
   scanf("%lf%lf%lf",&a, &b, &c);
 #ifdef DEBUG           /* 条件编译指令 */
   printf("DEBUG: a=%f, b=%f, c=%f\n",a,b,c);
#endif
   s=(a+b+c)/2;
#ifdef DEBUG          /* 条件编译指令 */
    printf("DEBUG: s=%f\n",s);
#endif
   area=sqrt(s*(s-a)*(s-b)*(s-c));
   printf("Area=%f\n",area);
   return 0;
}

