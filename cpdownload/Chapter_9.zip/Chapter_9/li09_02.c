/* 例9.2 带参宏指令应用示例 */
#include<stdio.h>
#define SUB(a,b)  a-b      /* 带参宏定义 ((a)-(b))  */
int main()
{   
   int a=3, b=2;
   int c;
   c=SUB(a,b);     /* 替换为：c=a-b; */
   printf("%d\n",c);
   c=SUB(3,1+2);   /* 替换为：c=3-1+2; */
   printf("%d\n",c);
   return 0;
}

