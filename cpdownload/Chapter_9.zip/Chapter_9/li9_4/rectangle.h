/* rectangle.h */
#ifndef RECTANGLE   /* 条件编译防止重复包含头文件 */
#define RECTANGLE
/* 在一个大的软件工程里面，可能会有多个文件同时包含一个头文件，当这些文件编译链接成一个可执行文件时，就会出现大量“重定义”的错误。在头文件中实用#ifndef #define #endif能避免头文件的重定义。 */
double rectangle_area(double w, double h);
double rectangle_perimeter(double w, double h);

#endif