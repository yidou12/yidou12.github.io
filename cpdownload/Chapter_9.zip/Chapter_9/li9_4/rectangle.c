/* rectangle.c */
#include<stdio.h>
double rectangle_area(double w, double h)
{   
   return  w*h;
}
double rectangle_perimeter(double w, double h)
{   
   return  2*(w+h);
}

