/* circle.c */
#include<stdio.h>
#include "circle.h"
double const pi=3.14159;
double circle_area(double r)
{   
   return  pi*r*r;
}
double circle_perimeter(double r)
{   
   return  2*pi*r;
}

