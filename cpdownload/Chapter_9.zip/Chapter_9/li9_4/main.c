/* 例9.4 设计一个多文件工程程序，其功能是计算圆和矩形的面积和周长。*/
/* main.c */
#include<stdio.h>
#include "circle.h"    /* 包含圆模块头文件 */
#include "rectangle.h" /* 包含矩形模块头文件 */
int main()
{   
   double r, w, h;
   printf("Input radius:\n");
   scanf("%lf", &r);              /* 输入圆的半径 */
   printf("Circle area=%f\n",circle_area(r));            /* 输出圆的面积 */
   printf("Circle perimeter==%f\n",circle_perimeter(r)); /* 输出圆的周长 */
   printf("Input width and height:\n");
   scanf("%lf%lf", &w, &h);        /* 输入矩形的长和宽 */
   printf("Rectangle area=%f\n",rectangle_area(w,h));            /* 输出矩形的面积 */
   printf("Rectangle perimeter==%f\n",rectangle_perimeter(w,h)); /* 输出矩形的周长 */
   return 0;
}
