/* statistic.h */
#ifndef STATISTIC   /* 条件编译防止重复包含头文件 */
#define STATISTIC
int find_max(const int a[]);
int find_min(const int a[]);
#endif
