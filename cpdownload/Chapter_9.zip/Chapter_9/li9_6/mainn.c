/* main.c */ 
#include<stdio.h>
#include "arrayioo.h"
#include "statistic.h"
#include "search.h"
int n=0;		/* 全局变量，数组当前的元素个数 */
static void menu();		/* 静态函数 */
int main()
{   
   int a[10]; 
   int i;
   int max,min,index;
   do
   {
	   menu();
	   printf("Please input your choice: ");
	   scanf("%d",&i);
	   switch(i)
	   {
		  case 1: input(a);               /* 输入数据 */
				  break;
		  case 2: output(a);              /* 输出数据 */
			      break; 
		  case 3: max=find_max(a);          /* 求最大值 */ 
				  printf("Max=%d\n",max);
			      break;
		  case 4: min=find_min(a);          /* 求最小值 */ 
				  printf("Min=%d\n",min);
			      break;
		  case 5: index=search(a);     /* 查找数据 */
				  printf("Index=%d\n",index);
				  break;
          case 0: break;
		  default:
			  printf("Error input,please input your choice again!\n");
	   }
   }while (i);
   return 0;
}

void menu( )
{
	printf("-------- 1. input data --------\n");
	printf("-------- 2. ouput data --------\n");
	printf("-------- 3. find max --------\n");
	printf("-------- 4. find min --------\n");
	printf("-------- 5. search data --------\n");
	printf("-------- 0. exit --------\n");
	return;
}
