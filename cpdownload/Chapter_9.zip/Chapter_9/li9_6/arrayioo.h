/* arrayio.h */
#ifndef ARRAYIO   /* 条件编译防止重复包含头文件 */
#define ARRAYIO
void input(int a[]);
void output(const int a[]);
#endif
