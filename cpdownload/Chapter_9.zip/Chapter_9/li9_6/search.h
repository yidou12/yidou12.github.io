/* search.h */
#ifndef SEARCH   /* 条件编译防止重复包含头文件 */
#define SEARCH
int search(const int a[]);
#endif
