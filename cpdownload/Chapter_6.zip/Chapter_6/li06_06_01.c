//
//  li06_06_01.c
//  chapter6
//
//  Created by Yi Dou on 2022/10/30.
//

#include <stdio.h>
#define ROW 3
#define COL 4

void printarr(int a[][COL]);

int main()
{
    int A[ROW][COL]={{1,4,7},{2,5,8},{3,6,9}};
    printarr(A);
    return 0;
}

void printarr(int a[][COL]) {
    
    int i,j;

    for (i=0;i<ROW;i++)
    {
        for(j=0;j<COL;j++)
            printf("%5d",a[i][j]);
        printf("\n");
    }
    
    
    
}

