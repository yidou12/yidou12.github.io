//
//  li06_05_01.c
//  chapter6
//
//  Created by Yi Dou on 2022/10/30.
//

#include<stdio.h>
#define N 3
int main()
{
    int A[N][N]={0}, B[N][N]={0};
    int Diag[N], sum=0;
    int i,j;
    for (i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
           scanf("%d",&A[i][j]); //输入数组A
    }
    
    for (i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
            printf("%5d",A[i][j]);
        printf("\n");
    }
    for(i=0;i<N;i++)
        Diag[i]=A[i][i];
   
    printf("Diag:\n");
    for(i=0;i<N;i++)
        sum += Diag[i];  //对角线求和
        printf("%5d",sum);
    
    printf("\n");
    for(i=0;i<N;i++){
        for(j=0;j<N;j++)
            B[i][j]= A[j][i];
    }
    printf("After transpose:\n");
    
    for(i=0;i<N;i++){
        for(j=0;j<N;j++)
            printf("%4d",B[i][j]);
        printf("\n");
    }
        
  
    
    return 0;
}
