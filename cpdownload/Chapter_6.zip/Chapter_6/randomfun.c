//
//  randomfun.c
//  chapter6
//
//  Created by Yi Dou on 2022/11/2.
//

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
    srand(1);
    printf("%d\n",rand());
    printf("%d\n\n",rand());
    
    srand(2);
    printf("%d\n",rand());
    printf("%d\n\n",rand());
    
    srand(time(NULL));
    printf("%d\n",rand());
    printf("%d\n\n",rand());
    
    printf("Time: %u\n",time(NULL));
    return 0;
}
