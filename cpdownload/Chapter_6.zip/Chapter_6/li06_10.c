/* li06_10.c */
#include <stdio.h>
#define SIZE 7                                                                   
void print(int a[],int n);
void insert(int a[],int n,int x);

int main( )
{
    int array[SIZE]={12,23,34,45,56,67};   /*用6个递增数值初始化使数组元素*/       
    int x;
    
    print(array,SIZE-1);         /*输出插入前数组元素*/                                                     
    printf("Please input x be inserted:");
    scanf ("%d",&x);           /*读入待插入的值x*/
    
    insert(array,SIZE-1,x);      /*插入*/
    printf("*******************\n");
    print(array,SIZE);         /*输出插入后数组元素，长度加1*/
    return 0;
}

/*函数功能：完成一维数组的输出
 函数参数： 两个形式参数分别表示待输出的数组、实际输出的元素个数
 函数返回值：无返回值
*/
void print(int a[],int n)
{
    int i;
    printf("The array is:\n");
    for (i=0;i<n;i++)
        printf("%5d",a[i]);
    printf("\n");
}
/*函数功能：完成一维数组的插入算法
 函数参数： 3个形式参数分别对应于待插入的数组、现有元素个数、待插入元素
 函数返回值：无返回值
*/

void insert(int a[],int n,int x)
{
    int i,j;
    for (i=0;i<n&&a[i]<x;i++);/*定位：查找待插入的位置i，循环停止时的i就是*/
    for (j=n-1;j>=i;j--)       /*移位：用递减循环移位，使i下标元素可被覆盖*/
    {
        a[j+1]=a[j];
        print(a,SIZE);
    }
    a[i]=x;                 /*插入：数组的i下标元素值赋值为插入的x*/                       
}
