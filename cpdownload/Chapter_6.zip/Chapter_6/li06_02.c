#include <stdio.h>
#define N 30                 /* 数组长度 */
int main()
{
	int i,fib[N]={0,1,1};       /* 0下标不用，从第1个月开始计,定义数组的前三项 */
	int n;
	do
    {
        printf("Input n:");
        scanf("%d",&n);
    }while(n<0||n>N);          /* 输入马满足要求的待求月份数 */
    
	for(i=3;i<=n;i++)
       fib[i]=fib[i-1]+fib[i-2];
    
	for(i=1;i<=n;i++)           
	{
		printf("%10d",fib[i]);
		if((i)%5==0)              /* 每行输出5个 */
            printf("\n");
	}
	return 0;
}
