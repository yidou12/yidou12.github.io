#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#define  ROW 3                        /*原始矩阵的行数*/
#define  COL 4                         /*原始矩阵的列数*/
int main()
{
	int array_a[ROW][ COL];             /*用来存储原始矩阵*/
    int array_b[ COL][ROW];             /*用来存储转置后的矩阵*/
	int i,j;
	srand(time(NULL));                  /*使用系统时钟作为随机数种子*/
    for(i=0;i< ROW;i++)
	{
		for(j=0;j< COL;j++)
			array_a[i][j]=rand()%100+1;  /*生成[1,100]的随机数*/
	}

	printf("Before transpose:\n");            
    for(i=0;i< ROW;i++)                   /*控制行*/
	{
		for(j=0;j< COL;j++)               /*控制列*/
			printf("%4d",array_a[i][j]);     
		printf("\n");                      
	}

    for(i=0;i< COL;i++)                     /*控制新矩阵的行*/
        for(j=0;j< ROW;j++)                 /*控制新矩阵的列*/
            array_b[i][j]=array_a[j][i];    /*注意array_a访问方法*/
    printf("After transpose:\n");              
	
	for(i=0;i< COL;i++)
	{
		for(j=0;j< ROW;j++)
			printf("%4d",array_b[i][j]);
		printf("\n");
	}
	return 0;
}
