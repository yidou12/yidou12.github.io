#include<stdio.h>
#define N 3
int main()
{
    int A[N][N]={0};
    int Diag[N];
    int sum=0;
    int i,j;

    for (i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
            scanf("%d",&A[i][j]); //输入数组A
        printf("\n");
    }
    
    for (i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
            printf("%5d",A[i][j]);
        printf("\n");
    }
    for(i=0;i<N;i++)
        Diag[i]=A[i][i];
    
    printf("Diag:\n");
    for(i=0;i<N;i++)
        sum += Diag[i];
    
        printf("%5d",sum);
    return 0;
}  
