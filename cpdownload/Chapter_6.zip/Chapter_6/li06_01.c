#include <stdio.h>
int main()
{
   float score[50]={0};	  /* 定义数组用于存储学生的考试成绩，初始化为0 */
   int num;
   float sum=0,average;   /* 定义变量分别用于存储总和和平均值 */
   int i;
   do
   {
       printf("Input the number of students:");
       scanf("%d",&num);      /* 输入符合要求的实际学生人数 */
    }while (num<=0||num>50);
    printf("Input the score :");
    
    for (i=0;i<num;i++)
    {
        scanf("%f",&score[i]);       /* 逐个输入学生的成绩 */
        sum += score[i];            /* 计算总分 */
    }
    average = sum/num;              /* 求平均分 */
    printf("The average is :%5.2f\n",average);
    return 0;
}
