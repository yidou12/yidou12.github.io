/* li06_09.c*/
#include <stdio.h>
#define SIZE 10

int find(int a[],int n,int x);        /*函数声明*/

int main()
{
int array[SIZE],i=0,n,x;
int pos;
    
do
{    printf("Please input n(1<=n<=%d):",SIZE);
    scanf("%d",&n);
}while (n<1||n>SIZE);                /*保证读入的n满足1≤n≤SIZE*/
    
printf("Please input %d elements:",n);

for (i=0;i<n;i++)
scanf("%d",&array[i]);                 /*读入数组元素*/
    
printf("Please input x be searched:");
scanf("%d",&x);                         /*读入待查找数据*/

pos=find(array,n,x);                         /*调用函数完成查找*/
    if(pos<n)
        printf("value=%d, index=%d\n",x,pos);
    else
        printf("Not present!\n");
return 0;
}
/*函数功能：  完成一维数组的查找算法
函数参数：  3个形式参数分别对应于待查找的数组、数组的有效元素个数以及
待查找的值
函数返回值：返回查询结果，若查询成功返回数组元素所在下标，不成功则返回数组长度值n*/
int find(int a[],int n,int x)
{
int i=0;
    while(i<n)                    /*循环条件为：如果未找到且未搜索完元素*/
    {
       if (x==a[i])                /*如果查找成功，i的值正好是元素下标*/
           break;
         i++;
    }
return i;
}

