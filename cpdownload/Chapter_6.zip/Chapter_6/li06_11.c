/* li06_11.c */
#include <stdio.h>
#define SIZE 5
/*函数功能：完成一维数组的输出
 函数参数：表示待输出的数组、数组元素个数
 函数返回值：无返回值 */
void print(int a[],int n)
{
    int i;
    printf("The array is:\n");
    for (i=0;i<n;i++)
        printf("%5d",a[i]);
	printf("\n");
}
/*函数功能：完成从一维数组中删除特定元素
 函数参数： 3个形式参数分别对应于待删除的数组、现有元素个数、待删除的元素值
 函数返回值：返回删除是否成功标志，1表示成功，0表示待删除的元素不存在*/
int delArray(int a[],int n,int x)
{
    int i,j;
    int flag=1;               /*是否找到待删元素的标志位，1找到，0未找到*/
    for (i=0;i<n &&a[i]!=x;i++) ;       /*查找x是否存在，此处循环体为空语句*/
    if (i==n)                     /*循环停止时如果i==n，则说明元素不存在*/
        flag=0;                                                           
    else                                                                 
    {                                                                   
        for (j=i;j<n-1 ;j++)
        {
            a[j]=a[j+1];                      /*前移覆盖i下标的元素*/
            print(a,SIZE); 
        }
          
    }                                                                      
    return flag;                                                              
}
int main( )
{
		int array[SIZE]={23,45,34,12,56};         /*初始化数组*/              
		int x;
		print(array,SIZE);                      /*输出删除前的数组*/
    
		printf("Please input x be deleted:");
		scanf("%d",&x);                       /*读入待删除的x*/
    
	    if(delArray(array,SIZE,x))/*调用delArray删除元素x*/
        {
            printf("*******************\n");
            print(array,SIZE-1);            /*如果成功输出删除后的数组元素*/
        }
  	    else                                                                 
            printf("can not delete x!\n");         /*否则给出未删除的提示信息*/
		return 0;
}
