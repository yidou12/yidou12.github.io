#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
    int card[13][4]={0};
    /*(Spade(黑桃)、Club(梅花)、Heart(红桃)、Diamond(方块))*/
	char kind[4]={'S', 'C', 'H', 'D'};
	char size[13]={'2','3','4','5','6','7','8','9','10','J','Q','K','A'};
	int i,j,k;
	int sig = 1;             /* 初始化第一个拿牌的是玩家1*/

	int total = 52;
	srand(time(NULL));       /* 当前时间作为随机数种子*/
	while (total)            /* 发牌过程*/
	{
        j=rand()%13;         /* 随机选择一行(数字)*/
        k=rand()%4;          /* 随机选择一列(花色)*/

        if (!card[j][k])     /* 随机生成的牌之前已经发过，则再次循环随机生成新的牌*/
        {
            card[j][k]=sig; 
            sig = - sig;      /* 下一轮发牌准备:玩家1 和玩家2轮流发牌*/
            total--;          /* 一直到所有52张牌都发完*/
       }
    }
					         
    printf("Player1: \n");    /* 输出发牌结果*/
     for(i=0;i<13;i++)        /* 按照数字和花色，输出每个玩家拿到的牌*/
    {
    	printf("%c : ",size[i]);
        for(j=0;j<4;j++)
        {
        	if (card[i][j]== 1)
           		 printf("%5c",kind[j]);
			else printf("%5c",' ');
    	}
        printf("\n");
    }

    printf("\n Player2: \n");
    for(i=0;i<13;i++)
    {
    	printf("%c : ",size[i]);
        for(j=0;j<4;j++)
        {
        	if (card[i][j]== -1)
           		 printf("%5c",kind[j]);
			else printf("%5c",' ');
    	}
        printf("\n");
    }
    return 0;
}
