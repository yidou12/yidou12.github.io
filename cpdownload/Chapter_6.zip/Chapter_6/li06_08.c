#include <stdio.h>
#define ROW 10
#define COL 10

void printAll(int (*num)[COL])
{
    int i,j;
    for(i=1;i<ROW;i++)
    {
        for(j=1;j<COL;j++)
            printf("%d*%d=%-4d",i,j,num[i][j]);
        printf("\n");
    }
}
void printDown(int num[][COL])
{
    int i,j;
    for(i=1;i<ROW;i++)
    {
        for(j=1;j<=i;j++)
        {
               printf("%d*%d=%-4d",i,j,num[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    int Nine[ROW][COL]={0};
    int i,j;
    int choice;
    for(i=1;i<ROW;i++)
        for(j=1;j<COL;j++)
            Nine[i][j]=i*j;
    printf("    1   Printf full table\n");
    printf("    2   Printf lower triangular table \n");
    printf("Please input your choice:");
    scanf("%d",&choice);
    switch(choice)
    {
    case  1:
        printAll(Nine);break;
    case 2:
        printDown(Nine);break;
    default:
        printf("Input error!\n");
    }
    return 0;
}
