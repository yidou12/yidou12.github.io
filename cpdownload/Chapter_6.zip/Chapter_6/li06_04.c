#include <stdio.h>
#define N 10                   /* 数组的长度 */

void printarr(int a[],int n);        /* 函数原型声明，功能：输出一维数组所有元素 */
int maxnum(int a[],int n);         /* 函数原型声明，功能：求一维数组中最大元素并返回 */

int main()
{
    int array[N]={0},i,n;                   /* 定义数组，i控制下标，n控制元素实际个数 */
	int max,min;                     /* 存最大、最小元素值，类型与元素类型一致 */
	do                             
	{	printf("Please input n(1<=n<=10):\n");
		scanf("%d",&n);
	}while (n<1||n>N); /* 保证读入的n满足1≤n≤N */
    
	printf("Please input %d elements:\n",n);
	for (i=0;i<n;i++)                
		scanf("%d",&array[i]);
    
    printarr(array,n);           /* 调用printarr函数输出数组的n个元素 */
    max=maxnum(array,n);      /* 调用maxnum函数求出最大元素值并赋值给max变量 */
    
    printf("max element:%d\n",max);       /* 输出最大元素值 */
	return 0;
}

/* 函数功能：输出一维数组
 函数参数： 两个形式参数分别表示待输出的数组、实际输出的元素个数 
 函数返回值：无 */
void printarr(int a[],int n)
{
    int i;
    printf("The elements are:\n");
	for (i=0;i<n;i++)                      
		printf("%5d",a[i]);
	printf("\n");
}
/* 函数功能：求一维数组中最大的元素
 函数参数： 第一参数对应待传递的数组，第二个整型参数表示数组的实际长度 
 函数返回值：最大值 */
int maxnum(int a[],int n)
{
    int i,max;
    max=a[0] ;                     /* 假定第一个元素是最大值 */
    for (i=1;i<n; i++)
    {               /* 从第二个元素到第n个元素与当前的最大值比较 */
        //printf("a[i]=%d\t, max=%d\n",a[i],max);
        if (a[i]>max)
            max=a[i];
        
    }          /* 当前元素值若大于max，则将值赋给max变量 */
    return max;
}
