#include <stdio.h>
#define SIZE 10                                                                                         
/*函数功能：完成一维数组的输出
 函数参数：表示待输出的数组、实际输出的元素个数
 函数返回值：无返回值
*/
void print(int a[],int n)
{    int i;
    printf("The array is:\n");
	for (i=0;i<n;i++)
		printf("%5d",a[i]);
	printf("\n");
}
/*函数功能：完成一维数组的冒泡排序算法
 函数参数： 两个参数分别是待排序数组及当前元素个数
 函数返回值：无返回值
*/
void BubbleSort(int a[], int n)
{
    int i, j,temp;
    for (i = 0; i < n-1; i++)    /*共进行n-1趟排序*/                                   
        for (j =n-1; j>i ; j--)  /*递减循环，从后往前比较*/
        {
            if (a[j ] < a[j-1])  /*两两比较，若后一个元素小则交换该组相邻元素*/
            {
                temp=a[j-1];
                a[j-1]=a[j];
                a[j]=temp;
            }
            print(a,n);
        }
                                                             
}
int main()
{
	int array[SIZE],i=0,n;
	do						
	{	printf("Please input n(1<=n<=%d):",SIZE);
		scanf("%d",&n);
	}while (n<1||n>SIZE);            /*保证读入的n满足1≤n≤SIZE*/
    
	printf("Please input %d elements:",n);
    for (i=0;i<n;i++)
		scanf("%d",&array[i]);         /*读入数组元素*/
    
    BubbleSort(array,n);              /*调用函数完成排序*/
    
	//print(array,n);
	return 0;
}
