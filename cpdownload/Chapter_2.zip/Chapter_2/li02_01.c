/*例2_1编写一个程序，实现从键盘输入两个整数，并计算输出两者的乘积*/
#include <stdio.h>
/*函数功能：计算两个整数的乘积
  入口参数：整型数a和b
  返回值：  整型数a和b之积
*/
int multiply( int a, int b)
{
	return (a*b);
}
/*主函数*/
int main( )
{
	int xx, yx, product;
	printf("Please input two integers:");
	scanf("%d%d",&xx, &yy);	/*输入两个整型数x和y*/
	//product = multiply (xx, yy);
	//product=multiply(xx, yy); /*调用函数multiply计算x和y的乘积*/
	//printf("The product is %d\n", product); /*输出x和y的乘积*/
	return 0; 
}