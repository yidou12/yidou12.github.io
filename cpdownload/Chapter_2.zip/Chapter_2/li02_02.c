﻿/*例2_2日期格式转换*/
#include <stdio.h>
int main()
{
	int year, month, day; /*定义变量分别存放年、月、日*/
	printf(" Please input a date (YYYY-MM-DD):");
	scanf("%d-%d-%d",&year, &month, &day);
	printf("Date notation in CN: %d/%02d/%02d\n",year, month, day);
	printf("Date notation in US: %02d/%02d/%d\n",month, day, year);
	printf("Date notation in UK: %02d/%02d/%d\n",day, month, year); 
	return 0;
}
