﻿/*例2_3作业等级的输入和输出*/
#include<stdio.h>
int main( )
{
		char grade1,grade2;         /*定义两个char型的变量用于存放作业等级*/
		grade1=getchar();			/*用getchar读入第1个字符返回给grade1*/
		getchar();                  /*忽略第2个字符*/
		grade2=getchar();          /*用getchar读入第3个字符返回给grade2*/
		printf("The first grade is:"); 
		putchar(grade1);			/*用putchar输出grade1*/
		putchar('\n');				/*用putchar输出换行符*/
		printf("The second grade is:"); 
	    putchar(grade2);			/*用putchar输出grade2*/
		putchar('\n');				/*用putchar输出换行符*/
		return 0;
}

