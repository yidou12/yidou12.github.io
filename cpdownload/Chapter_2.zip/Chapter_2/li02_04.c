/*例2_4计算圆的编辑和周长*/
#include<stdio.h>
int main( )  
{   
		const double pi=3.14159;			/*定义只读常量pi*/
		double r;						/*定义变量r，作为半径*/
		//pi=3.14;
		scanf("%lf",&r);					/*从键盘输入r的值*/
		printf("area=%.2f\n", pi*r*r);			/*计算圆的面积并输出*/
		printf("perimeter=%.2f\n", 2*pi*r);		/*计算圆的周长并输出*/
		return 0;
}   

