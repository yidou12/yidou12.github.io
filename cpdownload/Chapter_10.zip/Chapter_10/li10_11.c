#include <stdio.h>
#include <malloc.h>
struct Node                          /* 定义链表结点的类型 */
{
	int data;                         /* 数据域 */
	struct Node *next;                 /* 指针域 */
};
typedef struct Node Node;            /* 定义类型的别名为Node，方便使用*/

Node * Create( );					    /* 创建一个新的链表 */
void Print ( Node * head );				/* 打印链表 */
void Release( Node * head );				/* 释放链表所占的内存空间 */
Node* Insert( Node * head, int num );

	int main( )
{
	Node * head;                        /* 定义头指针head */
    int num;
	head = Create( );                     /* 创建一个新的链表，返回的头指针赋值给head */
Print(head);                            /* 链表的遍历输出每个元素的值 */
printf("请输入要插入的数:\n");
scanf( "%d", &num );
	head = Insert( head, num );                 /* 调用函数插入一个值 */
	printf("插入%d之后的链表:\n",num); 
	 Print( head );
	 Release( head );                     /* 释放链表每个结点的存储空间 */
	 return 0;
}

/*	函数功能：    创建一个单链表
	函数入口参数：无
	函数返回值： 链表的头指针
*/
Node * Create( )
{
	Node *head, *tail, *p;			    /* head、tail分别指向链表的头结点和尾结点 */
	int num;
	head = tail = NULL;			    /* 链表初始化: 空链表 */
	printf( "请输入一批数据，以-9999结尾: \n");
	scanf( "%d", &num );
	while( num != -9999 )				/* 用户数据输入未结束 */
	{
		p = (Node *) malloc ( sizeof(Node) );	/* 申请一块节点的内存用于存放数据 */
		p->data = num;			 /* 将数据存于新结点的data成员中 */
		p->next = NULL;           /* 新结点的指针域及时赋为空值 */
		if( NULL == head )          /* 如果原来链表为空 */
		{	head = p;				  /* 则将p赋值给head，p是刚申请的第一个结点 */
		}
		else                       /* 如果原来链表非空 */
		{
			tail->next = p;			  /* 则将新结点链入尾部成为新的最后一个结点 */
		}
		tail = p;					  /* 更新tail指针，让其指向新的尾结点处 */
		scanf( "%d", &num );         /* 继续读入数据 */
	}
	return head;                     /* 返回链表的头指针 */
}
/*	函数功能：    遍历单链表输出每个结点中的元素值
	函数入口参数：链表的头指针
	函数返回值： 无
*/
void Print ( Node * head )                     
{
	Node * p;                       /* 定义工作指针p */
	p=head;                        /* p从头指针开始 */
	if( NULL== head )               /* 如果链表为空输出提示信息 */
	{
		printf( "链表为空!\n" );
	}
	else
	{
		printf( "链表如下\n" );
		while( p != NULL )           /* 用 p来控制循环，p为空指针时停止 */
		{
			printf( "%d  ", p->data );  /* 输出 p当前指向的结点的元素值 */
			p=p->next;              /* p指向链表的下一个结点处 */
		}
	}
	printf( "\n" );
}
/*	函数功能：    释放单链表中所有的动态结点
	函数入口参数：链表的头指针
	函数返回值： 无
*/
void Release( Node * head )           /* 仍然是使用遍历的方法扫描每一个结点*/
{
	Node * p1, * p2;                 /* p1用来控制循环，p2指向当前删除结点处 */
	p1 = head;
	while ( p1 != NULL )
	{
		p2 = p1;                   /* p2指向当前删除结点处 */
		p1 = p1->next;              /* p1指向链表下一个结点位置处 */
		free(p2);                   /* 然后通过p2释放动态空间 */
	}
	printf( "链表释放内存成功!\n" );
}
Node* Insert( Node * head, int num )		/* 向链表中插入数据num */
{
Node *p, *p1, *p2;

p = ( Node * ) malloc ( sizeof(Node) );	/* 为待插入的数据申请一块内存 */
p->data = num;
p->next = NULL;

p1 = head ;
while (p1 && p->data > p1->data )	/* 确定插入位置 */
{		
	p2 = p1;
	p1 = p1->next;
}
if (p1 == head)			  	 /* 插入位置在第一个结点之前或原链为空 */
{								
	head = p; 
}
else							  /* 插入位置在链表中间或末尾 */
{
	p2->next = p;
}
p->next = p1;
	
printf( "数据插入成功!\n" );
return head;
}