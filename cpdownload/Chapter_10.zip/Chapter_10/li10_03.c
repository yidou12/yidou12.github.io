#include <stdio.h>
#include <string.h>
struct Date                                 
{
	int year;				      /* 年 */
	int month;			      /* 月 */
	int day;				       /* 日 */
};
typedef struct Date Date;         /* 再为结构体类型 struct Date起个别名Date */
struct Student                    /* 先定义结构体类型 struct Student */
{
	int ID;					   /* 学号 */
	char name[20];			   /* 姓名 */
	Date birthday;				   /* 生日 */
	char sex;					   /* 性别: 'M'表示男; 'F'表示女 */
	double score;				   /* 成绩 */
};
typedef struct Student Student;      /* 再为结构体类型 struct Student起个别名Student */

int main( )
{
    /* 定义结构体数组并初始化 */
        Student st[3] = {
            { 1001, "Zhang", {1992, 5, 21}, 'F', 83 },
            { 1002, "Wang", {1993, 6, 18}, 'M', 66 } 
        }, *p;
    /* p = st; */
	int i;
	/* 用第一种方式访问结构体成员，st[2]各个成员的初值原来均默认为0 ，现对其成员一一赋值 */
	st[2].ID = 1003;
	strcpy( st[2].name, "Li" );
	st[2].birthday.year = 1993;
	st[2].birthday.month = 7;
	st[2].birthday.day = 22;
	st[2].sex = 'M';
	st[2].score = 65;
    
	/* 用第二种方式访问结构体成员 */
	for ( i=0 ; i<3 ; i++ )
	{
		printf( "%d %s %d.%d.%d %c %f\n", (st+i)->ID, (st+i)->name, (st+i)->birthday.year, (st+i)->birthday.month, (st+i)->birthday.day, (st+i)->sex, (st+i)->score );
	}
    printf("=============\n");
    
    for(p=st;p<st+3;p++)
    {
        printf( "%d %s %d.%d.%d %c %f\n", p->ID, p->name, p->birthday.year, p->birthday.month, p->birthday.day, p->sex, p->score );
    }
	return 0;
}
