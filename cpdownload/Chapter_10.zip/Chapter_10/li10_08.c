#include<stdio.h>
struct Node
{
	int data;
	struct Node *next;
};
int main( )
{
	struct Node n1, n2, n3, *head, *p;
	head = &n1;                 /* 直接将一个结构体变量n1的地址赋值给了头指针 */
	n1.data = 3;
	n1.next = &n2;              /* 直接将变量n2的地址赋值给了n1的指针域使n2在n1后面 */
	n2.data = 4;
	n2.next = &n3;
	n3.data = 6;
	n3.next = 0;                 /* 直接将变量n3的地址赋值给了n2的指针域使n3在n2后面 */
	p = head;                    /* 工作指针p从头指针位置开始 */
		while ( p != '\0' )             /* 此循环完成链表的遍历，即一个结点一个结点地访问 */
	{
		printf("%d  ", p->data);    /* 输出结点的数据域的值 */
		p = p->next;              /* 工作指针指向下一个结点处 */
	}
	printf("\n");
	return 0;
}