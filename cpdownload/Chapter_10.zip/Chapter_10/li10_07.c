#include <stdio.h>
enum Seasons { Spring=4, Summer=1, Autumn, Winter };
typedef enum Seasons Seasons;
int main( )
{	
	Seasons day[4] = { Summer };                                     
	int i;
	day[1] = 2;                                                     
	day[2] = 6;
	for( i=0 ; i<4 ; i++ )
	{
		printf ( "day[%d]: %d ", i, day[i] );                                
		switch( day[i] )
		{
		case  Spring:
			printf("Spring\n");
			break;
		case  Summer:
			printf("Summer\n");
			break;
		case  Autumn:
			printf("Autumn\n");
			break;
		case  Winter:
			printf("Winter\n");
			break;
		default:
			printf("Wrong!\n");
		}
	}
	return 0;
}