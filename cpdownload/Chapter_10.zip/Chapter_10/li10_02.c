#include <stdio.h>
#include <string.h>
struct Date                             
{
	int year;			      /* 年 */
	int month;		      /* 月 */
	int day;				  /* 日 */
};
typedef struct Date Date;    /* 再为结构体类型 struct Date起个别名Date */

struct Student               /* 先定义结构体类型 struct Student */
{
	int ID;				  /* 学号 */
	char name[20];		  /* 姓名 */
	Date birthday;			  /* 生日 */
	char sex;			      /* 性别: 'M'表示男; 'F'表示女 */
	double score;		      /* 成绩 */
};
typedef struct Student Student; /* 再为结构体类型 struct Student起个别名Student */

int main( )
{
    Student s1, *p;        /* 定义 Student类型的变量和指针 */
    p = &s1;             /* 定义结构体变量的地址赋值给结构体指针 */ 
	
    s1.ID = 2001;       /* 通过结构体变量用点运算符直接为成员赋值 *
							/* 通过指针访问结构体变量的各个成员 */
    p->ID = 2022;
    strcpy( p->name, "Liang" );  /* 注意年、月、日的访问，后一个用点运算符 */
	p->birthday.year = 1978;        
	p->birthday.month = 4;
	p->birthday.day = 20;
	p->sex = 'M';
	p->score = 100;
    
        printf( "%d %s %d.%d.%d %c %.2f\n", p->ID, p->name, p->birthday.year, p->birthday.month, p->birthday.day, (*p).sex, (*p).score );                                  
	return 0;
}
