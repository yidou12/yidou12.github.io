#include <stdio.h>
#include <string.h>
struct Date                   /* 先定义结构体类型 struct Date */
{
	int year;					/* 年 */
	int month;			    /* 月 */
	int day;					/* 日 */
};                 /* 结构体一般定义在main函数之外，是全局变量，方便别的函数访问 */
typedef struct Date Date;        /* 再为结构体类型 struct Date起个别名Date */

struct Student                 /* 先定义结构体类型 struct Student */
{
	int ID;					/* 学号 */
	char name[20];		    /* 姓名 */
	Date birthday;				/*结构体嵌套 生日 */
	char sex;					/* 性别: 'M'表示男; 'F'表示女 */
	double score;				/* 成绩 */
};
typedef struct Student Student;  /* 再为结构体类型 struct Student起个别名Student */

int main( )
{
    struct Student s1 = { 1001, "Zhu", { 1991, 3, 12 }, 'F', 78 };
    /* 定义结构体变量，定义时直接初始化 */
    struct Student s5 = { 1005, "yang", { 1996, 1, 2 }, 'M'  };
    
    Student s2, s3, s4;
		/* 使用别名定义，从键盘读入,对每个成员依次赋值，注意生日的年月日数据读入，要用两次点运算符 */
    scanf( "%d%s%d%d%d %c%lf", &s2.ID, s2.name, &s2.birthday.year, &s2.birthday.month, &s2.birthday.day, &s2.sex, &s2.score );	               //1002 Tang 1993 11 26M 87
	
    s3 = s1;                   /* 用同类型变量来赋值 */
	/* 以下对每个成员依次赋值 */
	s4.ID = 1004;
	strcpy( s4.name, "Liu" );
	s4.birthday.year = 1992;
	s4.birthday.month = 7;
	s4.birthday.day = 5;
	s4.sex = 'F';
	s4.score = 80;
    
/* 以下输出结构体变量各个成员的值，注意生日中年、月、日数据要用两次点运算符 */
	    printf( "%d %s %d.%d.%d %c %lf\n", s1.ID, s1.name, s1.birthday.year, s1.birthday.month, s1.birthday.day, s1.sex, s1.score );
	    printf( "%d %s %d.%d.%d %c %lf\n", s2.ID, s2.name, s2.birthday.year, s2.birthday.month, s2.birthday.day, s2.sex, s2.score );
	    printf( "%d %s %d.%d.%d %c %lf\n", s3.ID, s3.name, s3.birthday.year, s3.birthday.month, s3.birthday.day, s3.sex, s3.score );
	    printf( "%d %s %d.%d.%d %c %lf\n", s4.ID, s4.name, s4.birthday.year, s4.birthday.month, s4.birthday.day, s4.sex, s4.score );
        printf( "%d %s %d.%d.%d %c %lf\n", s5.ID, s5.name, s5.birthday.year, s5.birthday.month, s5.birthday.day, s5.sex, s5.score );
	return 0;
}
