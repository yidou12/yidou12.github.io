#include <stdio.h>
#include <string.h>
struct Student
{
	int ID;							 /* 学号 */
	char name[20];					 /* 姓名 */
	double score;						 /* 成绩 */
};
typedef struct Student Student;

/* 函数功能：更新结构体成员值, 传值调用
  函数参数：结构体类型的变量
  函数返回值：无返回值
*/
    void renew_value1( Student st )            /* 传值调用方式 */                     
{
    st.ID=1003;
    strcpy(st.name, "Jean");
st.score=98;   
}	
/* 函数功能：更新结构体成员值, 传地址调用
  函数参数：结构体类型的指针
  函数返回值：无返回值
*/
    void renew_value2( Student *pt )	    	 /* 传地址调用方式 */                   
{
    pt->ID=1004;
    strcpy(pt->name, "Dell");
pt->score=98;     
}
int main( )
{
Student st1={1001, "Tom", 95}, st2={1002, "Jack", 93};
/* 输出函数调用前结构体变量中各成员的值 */
printf("%d %s %f\n", st1.ID, st1.name, st1.score);
printf("%d %s %f \n", st2.ID, st2.name, st2.score);
        renew_value1(st1);          /* 传值调用方式 */                       
        renew_value2(&st2);         /* 传地址调用方式 */                      
/* 输出函数调用后结构体变量中各成员的值 */
printf("%d %s %f \n", st1.ID, st1.name, st1.score);
printf("%d %s %f \n", st2.ID, st2.name, st2.score);
return 0;
}
