#include <stdio.h>
struct Student
{
	int ID;							/* 学号 */
	char name[20];					/* 姓名 */
	double score;						/* 成绩 */
};
typedef struct Student Student;

int Input( Student [ ] );			        /* 从键盘读入数组元素, 并返回数组长度 */
void Sort( Student [ ], int len );			/* 对数组前len个元素进行排序 */
void Output(const Student [ ], int len );		/* 输出数组的前len个元素 */

int main( )
{
	Student st[10];
	int num;
	num = Input( st );                 /* 调用函数读入结构体数组的num个元素 */                
	Output( st, num);               /* 调用函数输出排序前的结构体数组的num个元素 */
	Sort( st, num );                   /* 调用函数对数组中元素根据分数进行排序 */
	Output( st, num );               /* 调用函数输出排序后的结构体数组的num个元素 */
	return 0;
}
/* 函数功能：读入一维结构体数组的各个成员的值并返回元素个数
 函数参数：1个形式参数表示待输入的结构体数组
 函数返回值：int型，返回已读入的元素个数
*/
int Input( Student s[ ] )                /* 读入学生信息 */
{
	int i, n;
	do
	{
		printf("Enter the sum of students: \n");
		scanf("%d", &n);
	} while ( n<=0 || n>10 );
	for ( i=0 ; i<n ; i++ )
	{
		printf("Enter %d-th student : ", i+1);
		scanf("%d%s%lf", &s[i].ID, s[i].name, &s[i].score);
	}
	return n;
}
/* 函数功能：对一维结构体数组根据分数成员的值进行由大到小的排序
 函数参数：2个形式参数表示结构体指针以及待排序的元素个数
 函数返回值：无返回值
*/
void Sort( Student st[ ], int len )			   /* 选择法排序 */
{
	int i, k, index;
	Student temp;
	for ( k=0 ; k < len-1 ; k++ )
	{
		index = k;
		for( i=k+1 ; i<len ; i++ ) 
		   if ( st[i].score > st[index].score )  /* 注意：此处比较两个数组元素的分数成员 */
				index = i;
		if ( index != k )
		{	
			temp = st[index];
			st[index] = st[k];
			st[k] = temp;
		}
	}
}
/* 函数功能：完成一维结构体数组的输出
 函数参数：两个形式参数分别表示待输出的数组、数组的实际元素个数
 函数返回值：无返回值
 */
void Output(const Student s[ ], int len )       /* 输出学生信息 */
{
	int i;
	printf("ID   Name     Score\n");
	for ( i=0 ; i<len ; i++ )
	{
		printf("%4d   %-8s  %.0f\n", s[i].ID, s[i].name, s[i].score);
	}
}