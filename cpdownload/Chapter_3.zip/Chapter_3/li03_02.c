﻿/*例3_2 验证丢番图规则*/
#include<stdio.h>
#include<math.h>
int main( )
{
	int a,b;    /*定义整型变量a和b*/
	int x,y,z;  /*定义整型变量x,y,z为勾股定理方程的解*/
	int t;
	int n=2;
	printf("Please input a and b:");
	scanf("%d%d",&a, &b);
	t=(int)sqrt(2*a*b);  /*计算2ab的平方根并取整*/
	printf("a=%d, b=%d\n",a,b);
	/*验证2ab是否为完全平方数，并输出验证结果*/
	printf("2ab %s a perfect square number.\n",t*t==2*a*b? "is" : "is NOT");
	/*根据丢番图的规则计算x,y,z*/
	x=a+t;  
	y=b+t;
	z=a+b+t;
	printf("x=%d, y=%d, z=%d\n",x,y,z);
	/*验证x,y,z是否满足勾股定理方程，并输出验证结果*/
	printf("(%d,%d,%d) %s a solution of the Pythagorean Theorem equation.\n",
		   x, y, z, x*x+y*y==z*z? "is" : "is NOT");
	return 0;
}

