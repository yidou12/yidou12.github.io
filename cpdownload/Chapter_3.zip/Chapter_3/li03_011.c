#include<stdio.h>
int main( )
{
	int x =3;
	int a=3,b=4,c=5,d, m, n; 
	printf("%d\n",0<x<5);
	printf("%d\n",(x>10)||(x<5));
	printf("%d\n",(x>10)&&(x<5));
	printf("%d\n",x>5 && x<10);

	 
	/*printf("%d\n", d=a>b?(a>c?a:c):(b<c?c:b));
	a=b=c=d=m=n=0;
	 
	printf("%d\t%d\t%d\n", (m=a)&&(n=c==d),m,n);

	n = 3;
    n += n-= n*n;
	printf("%d \n",  n);

	x=3;
	n=x++; 
	printf("%d\t%d\n",n,x); */
	 


	 
	return 0;
}