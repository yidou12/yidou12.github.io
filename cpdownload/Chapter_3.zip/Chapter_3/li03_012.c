#include<stdio.h>
int main( )
{
int i=1, j=2, k=3, m, n, p;
int x =14;  
int a = 4, b;
 
 m=++i;  
 n=j--; 
 p=(++m)*(n++)+(--k);  
 printf("%d\n",p);

 k=9;
 printf("%d\n",k=(x%=k)-(k%=4));

 b=a<<1;
 printf("%d\n",b);



}