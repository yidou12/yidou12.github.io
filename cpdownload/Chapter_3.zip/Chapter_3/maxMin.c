#include<stdio.h>

int main()

{
int a,b,c,max,min;

scanf("%d%d%d",&a,&b,&c);

//max=a>b?(a>c?a:c):(b>c?b:c);
//printf("max=%d",max);
min =a<b?(a<c?a:c):(b<c?b:c);
printf("min=%d",min);

return 0;

}