/* 例11.2  读取收货信息文件D:\CV.txt的内容，并原样输出至屏幕。*/
/* li11_02.c: fgetc函数调用示例 */
#include<stdio.h>
#include<stdlib.h>
int main( )
{	
	FILE *fp;                                                       
	char ch;
	fp = fopen( "CV.txt", "r" );		/* 以"读"的方式打开文本文件 */  
	if( fp == 0 )                       /* 文件打开失败 */             
	{
		printf( "file error\n" );
		exit(1);
	}
	while( ( ch = fgetc(fp) ) != EOF )	    /* 读文件操作 */               
	{
		putchar(ch);                  /* 屏幕输出刚刚读出的字符内容 */ 
	}
	putchar( '\n' );
	fclose(fp);					    /* 关闭文件 */                 
	return 0;
}
