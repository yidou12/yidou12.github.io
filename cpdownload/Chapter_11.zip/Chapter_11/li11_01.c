/* 例11_1 :  将个人收货信息从键盘输入，以'#'结尾，
内容存至文本文件D:\CV.txt中。 
*/
/* li11_01.c:  fputc函数调用示例 */
#include<stdio.h>
#include<stdlib.h>                
int main( ) 
{	
	FILE *fp;          /* 首先定义文件指针 */                                    
	char ch;
	fp = fopen( "CV.txt", "w" );	  /* 以"W"方式打开文本文件 */       
	if ( fp == 0 )					  /* 文件打开后需判断，如果失败 */    
	{
		printf( "file error\n" );	   
		exit(1);
	}
	printf( "Enter a text ( end with '#' ):\n");
	ch = getchar( );
	while( ch != '#' )				  /* 写文件操作 */                   
	{
		fputc(ch, fp);               /* 调用fputc将刚读的字符写到文件*/  
		ch = getchar( );
	}
	fclose(fp);					 /* 关闭文件 */                      
	return 0;
}
