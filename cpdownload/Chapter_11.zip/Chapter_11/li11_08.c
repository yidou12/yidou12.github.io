/* 例11.8  本例将给出对同一组结构体信息以文本文件和二进制文件
进行操作的综合范例。
以例11.4生成的d:\\sortedScore.txt为原始数据文件，
将该文本文件内容作为数据源，通过菜单选择执行多种功能：
二进制文件的读写操作、文本文件的复制、文本文件的读出、
屏幕显示所有记录信息等。
*/
/* li11-08.c 文件应用的综合示例 */  
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 100      
typedef struct Student
{	
int ID;			                   /* 学号 */
	char name[20];	                   /* 姓名 */
	double score;	                       /* 成绩 */
	int rank;                            /* 名次*/
}STU;
void Menu( );                           /* 显示菜单 */
int ReadTextFile(char *fname,STU st[]) ;     /* 从文本文件读出数据 */
void PrintScreen(STU st[],int n);            /* 屏幕显示所有记录 */
int ReadBiFile(char *fname,STU st[]);       /* 从二进制文件读出数据 */
void WriteBiFile(char *fname,STU st[],int n);  /* 向二进制文件写入数据 */
void CopyFile(char *fname1,char *fname2) ;  /* 文本文件的复制 */
void Clear(STU st[],int n);                 /* 清空结构体数组中各记录信息 */
int main( )
{
	STU stu[N];                        /* 定义一个结构体数组存放学生记录 */
	char filename1[20],filename2[20];      /* 文件名 */
	int num=0;                         /* num存放记录实际条数 */
int choice;                          /* 用于读入菜单选项编号 */
do
{	Menu( );                       /* 显示菜单 */
		printf("input your choice:  ");
		scanf("%d",&choice);             /* 读入选项 */
		switch(choice)                   /* 根据选项执行对应功能 */
		{case 1:  printf("Please input source text file name:  ");
	            scanf( "%s", filename1 );   /* 读入文本文件名 */	
                num=ReadTextFile(filename1,stu); /* 读文件数据于结构体数组 */
                break;
	     case 2:  PrintScreen(stu,num);
			    break;
		 case 3:	printf("Please input binary file name:  ");
	            scanf( "%s", filename1 );    /* 读入二进制文件名 */
                WriteBiFile(filename1,stu,num);  /* 将数据写入二进制文件 */
			    break;
		 case 4:  printf("Please input binary file name:  ");
	            scanf( "%s", filename1 );        /* 读入二进制文件名 */
			    num=ReadBiFile(filename1,stu);  /* 从二进制文件读出数据 */
			    break;
		 case 5:  printf("Input two filenames:  ");
			    scanf("%s%s",filename1,filename2);
			    CopyFile(filename1,filename2);  /* 复制文本文件 */
			    break;
		 case 6:  Clear(stu,num);               /* 清空结构体数组中数据 */
			     break;
		 case 0:	 printf("Exit!\n");
			     break;
		 default:	 printf("Error input\n");
		}
	}while (choice);                           /* choice为0时结束循环 */
	return 0;
} 
/* 函数功能：从文本文件读出数据
函数参数： 两个形式参数分别为文件名和结构体指针
函数返回值：从文件中实际读出来的记录条数
*/
int ReadTextFile(char *fname,STU st[])       
{
	int i=0;
FILE *fp;                                /* 定义文件指针 */
	fp=fopen(fname,"r");                       /* 打开文本文件准备读入数据 */
	if ( fp == 0 )                              /* 如果文件打开失败 */
	{	printf( "source text file error\n" );
		exit(1);
	}
fscanf( fp, "%d%s%lf%d", &st[i].ID, st[i].name, &st[i].score,&st[i].rank);	
	while( !feof(fp) )                    /* 当文件未结束时循环不断读出记录 */
	{	i++;	                        	    /* 下标加1 */
	    fscanf( fp, "%d%s%lf%d", &st[i].ID, st[i].name, &st[i].score,&st[i].rank);		}
	fclose(fp);                               /* 关闭文件 */
	return i;                                 /* 返回记录条数 */
}
/* 函数功能：将所有数据写入二进制文件
函数参数： 3个形式参数分别为文件名、结构体指针、记录的条数
函数返回值：无返回值
*/
void WriteBiFile(char *fname,STU st[],int n)    
{	FILE *fp;
	fp=fopen(fname,"wb");                 /* 写方式打开二进制文件 */
    if ( fp == 0 )                          /* 如果文件打开失败 */
	{	printf( "open binary file error\n" );
		exit(1);
	}
	fwrite(st,sizeof(STU),n,fp);              /* 一次性写入n条记录 */
	fclose(fp);
}
/*函数功能：从二进制文件中读出所有记录信息
函数参数： 两个形式参数分别为文件名和结构体指针
函数返回值：从文件中实际读出的记录条数
*/
int ReadBiFile(char *fname,STU st[])         /* 从二进制文件读出数据 */
{	int i=0;
	FILE *fp;                           /* 定义文件指针 */
	fp=fopen(fname,"rb");                 /* 读方式打开二进制文件 */
	if ( fp == 0 )                         /* 如果文件打开失败 */
	{	printf( "open binary file error\n" );
		exit(1);
	}	
    fread(&st[i],sizeof(STU),1,fp);	       /* 从文件中读出0下标记录 */
while( !feof(fp) )                     /* 当文件未结束时循环 */
	{	
i++;                           /* 下标加1以备读入*/		
	    fread(&st[i],sizeof(STU),1,fp);	  /* 读一条记录 */
	} 
fclose(fp);                          /* 关闭文件 */
	return i;                            /* 返回实际有效记录条数 */
}
/* 函数功能：屏幕显示所有记录信息
函数参数： 两个形式参数分别为结构体指针和记录条数
函数返回值：无返回值
*/
void PrintScreen(STU st[],int n)           
{	int i;
	for (i=0;i<n;i++)
		printf(  "%d %-8s\t%.2f%6d\n", st[i].ID, st[i].name, st[i].score,st[i].rank );
}
/* 函数功能：文本文件原样复制
函数参数： 两个形式参数分别是源文件名和目标文件名
函数返回值：无返回值
*/
void CopyFile(char *fname1,char *fname2) 
{
	FILE *fp1,*fp2;                   /* 两个文件指针对应打开源和目标文件 */
	char ch;
	fp1=fopen(fname1,"r");             /* 以读方式打开源文件 */
	fp2=fopen(fname2,"w");            /* 以写方式打开目标文件 */
	if (fp1==0 || fp2==0)
	{
		printf("File open error\n");
		exit(0);
	}
	while( ( ch = fgetc(fp1) ) != EOF )	    /* 从源文件读一个字符 */
	{ 
		fputc( ch, fp2 );		    	/* 将该字符原样写入目标文件写 */
	}
	fclose( fp1 );                      /* 关闭源文件 */
	fclose( fp2 );                      /* 关闭目标文件 */
}
/* 函数功能：显示菜单
函数参数： 无形式参数
函数返回值：无返回值
*/
void Menu( )
{	printf("------0. 退出                ------\n");
	printf("------1. 从文本文件中读取信息------\n");
	printf("------2. 屏幕显示所有记录信息------\n");
	printf("------3. 将信息写入二进制文件------\n");
	printf("------4. 从二进制文件读取信息------\n");
	printf("------5. 原样复制文件        ------\n");
	printf("------6. 清空结构体数组的内容------\n");
}
/* 函数功能：清空结构体数组的内容
函数参数：两个形式参数分别为结构体指针和记录条数
函数返回值：无返回值 
*/
void Clear(STU st[],int n)            
{	int i;
	for (i=0;i<n;i++)                /* 所有成员置0或置空串 */
	{	st[i].ID=0;
		strcpy(st[i].name,"");
		st[i].score=0.0;
		st[i].rank=0;
	}
}
