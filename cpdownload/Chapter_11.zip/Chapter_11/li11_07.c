/*  例11.7  修改文本文件中的内容（文件名由键盘输入），
将文件中所有的小写字母改为大写字母。
*/
/* li11_07.c: fseek函数示例 */
#include<stdio.h>
#include<stdlib.h>
int main( )
{	
	FILE *fp;                                                            
	char fname[20];
	char ch;
	printf("Please input file name:\n");
	scanf("%s",fname);
	fp = fopen( fname, "r+" );				/* 打开文本文件, 读写方式 */     
	if ( fp == 0 )							/* 文件打开失败 */
	{		printf( "open file error\n" );	   
		exit(1);
	}
	while( ( ch = fgetc(fp) ) != EOF)         /* 逐个读入文件中的字符 */           
	{
		if ( ch >= 'a' && ch <= 'z')          /* 如果是小写字母字符 */
		{	ch -= 32;                    /* 修改为对应的大写字母字符 */
			fseek ( fp, -1L, 1 );			   /* 回退1个字节，到刚才字符位置 */
			fputc ( ch, fp );               /* 写入修改后的字符 */              
			fflush( fp );				   /* 清空缓冲区,将其中的内容输出 */ 
		}
	}
	fclose(fp);                                                           
	return 0;
}
