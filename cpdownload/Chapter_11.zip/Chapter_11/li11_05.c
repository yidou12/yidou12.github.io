/*  例11.5  有一批学生的数据，包括学号、姓名、考试成绩等信息，
要求使用fwrite函数将其存入文件D:\computer.dat文件中。
*/
/* li11_05.c: fwrite函数示例 */
#include<stdio.h>
#include<stdlib.h>
typedef struct Student
{
	int ID;					           /* 学号 */
	char name[20];				       /* 姓名 */
	double score;			               /* 成绩 */
}STU2;
int main( )
{	
	FILE *fp;                                                            
	STU2 stu[3] = {{ 1001, "Tom", 77 }, { 1002, "Jack", 93 }, { 1003, "Lisa", 86} };
	fp = fopen( "computer.dat", "wb" );		/* 打开二进制文件, 写方式 */     
	if ( fp == 0 )							/* 文件打开失败 */                 
	{
		printf( "file error\n" );
		exit(1);
	}
	fwrite( stu, sizeof(STU2), 3, fp);          /* 将3条记录写入文件 */           
	fclose(fp);                            /* 关闭文件 */                      
	return 0;
}
