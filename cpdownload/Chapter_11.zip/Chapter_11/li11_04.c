/* 例11.4  事先用记事本创建了一个文本文件，
存放了学生的计算机考试成绩，具体信息如下，
包含了8个学生的学号、姓名、分数和排名（初始排名均设为0）：
101  zhangli    91  0
102  wanghua   82  0
103  zhouwen   76  0
104  wujia      91  0
105  nikuang    98  0
106  zhuzhu     82  0
107  liqin       91  0
108  gedun      89  0
请从该原始文件中读出所有学生的信息，
然后按考试成绩由高分到低分排名，并计算出每个学生的名次，
相同分数名次相同，最后将排过名的记录再依次存入
另一个文件中同时屏幕显示。
源文件名和排名后的文件名均由键盘输入提供。
*/
/* li11_04.c: fscanf,fprintf函数示例 */   
#include<stdio.h>
#include<stdlib.h>
#define N 100            /* N存放记录条数 */
typedef struct Student
{	int ID;	        	/* 学号 */
	char name[20];		/* 姓名 */
	double score;	        /* 成绩 */
	int rank ;             /* 名次，初始为0 */
}STU;                   /* 结构体类型的别名为STU */
int ReadFile(char *fname,STU st[]) ;  /* 从文件读出原始数据 */               
void SortRank(STU st[],int n) ;           /* 根据成绩排序并求名次 */             
void WriteFile(char *fname,STU st[],int n); /* 将排名次后的记录存文件并输出 */ 
	
int main( )
{	STU stu[N];                  /* 定义一个结构体数组存放学生记录 */
	char filename[20];             /* 文件名 */                           
	int num=0;
	printf("Please input source file name:\n");
	scanf( "%s", filename );  	    /* 读入原始数据文件名 */	            
    num=ReadFile(filename,stu);    /* 调用函数从文件读记录到结构体数组 */
	SortRank(stu,num);                 /* 调用函数根据成绩排序并求名次 */    
    printf("Please input sorted file name:\n");
	scanf( "%s", filename );         /* 读入排序后的目标文件名 */	        
    WriteFile(filename,stu,num);     /* 将排名次后的记录存文件并输出 */    
	return 0;
}
/* 函数功能：从文本文件中读出所有记录的初始值
 函数参数： 第1个形参为文件名，第2个形参为结构体指针
 函数返回值：整型，返回从文件中实际读出来的记录条数
*/
int ReadFile(char *fname,STU st[])    
{	int i=0;                       /* 此处i应初始化为0 */
	FILE *fp;                     /* 定义文件指针 */                    
	fp=fopen(fname,"r");            /* 打开文本文件准备读入数据 */        
	if ( fp == 0 )                   /* 如果文件打开失败 */               
	{	printf( "source file error\n" );
		exit(1);
	}
/*下一条语句是从文件中读出第一条记录存入数组下标0处*/
	fscanf( fp, "%d%s%lf%d", &st[i].ID, st[i].name, &st[i].score,&st[i].rank);    
	while( !feof(fp) )               /* 当文件未结束时进入循环 */   
		/* 对于文件来说，无论是空文件，还是存有信息的文件，当文件被打开，
		光标处于默认的开头时，光标后都有信息。 */
	{   i++;                     /* 结构体数组的下标加1然后继续读入 */		        
	    fscanf( fp, "%d%s%lf%d", &st[i].ID, st[i].name, &st[i].score,&st[i].rank);
}
	fclose(fp);                    /* 关闭文件 */                          
	return i;                      /* 返回实际记录条数 */
}
/* 函数功能：根据分数进行由高分到低分排序，并求排名
 函数参数：第1个形参为结构体指针，第2个形参表示参加排序的记录条数
 函数返回值：无返回值
*/
void SortRank(STU st[],int n)       
{	int i,j,k;                   
    STU temp; 
	for (i=0;i<n-1;i++)         /* 此处为简单选择法排序 */
	{	k=i;                 /* k保存本趟最大分数的结构体下标 */
		for (j=i+1;j<n;j++)
			if (st[j].score >st[k].score )  /* 比较的依据是结构体的分数成员 */
				k=j;         /* 每趟的任务是找出分数最大元素的下标k */
		if (k!=i)              /* 如果本趟最高分数记录不到位则交换 */
		{	temp=st[i];
			st[i]=st[k];
			st[k]=temp;
		}
	}                        /* 至此记录已按分数由高到低排序结束 */
    st[0].rank=1;               /* 0下标记录的名次是第1名 */
	for (i=1;i<n; i++)          /* 求其他记录的名次 */     
	{	
		if(st[i].score==st[i-1].score)  /* 如果相邻元素的分数值相同 */
		    st[i].rank=st[i-1].rank;    /* 则名次相同 */
	    else 
	        st[i].rank=i+1;      /* 否则名次值为下标值加1 */
	}
}
/* 函数功能：将完整的结构体记录都写入文本文件，同时在屏幕显示
 函数参数：3个形式参数分别为文件名，结构体指针和记录条数
函数返回值：无返回值
*/
void WriteFile(char *fname,STU st[],int n)  
{	
int i;
	FILE *fp;                                                        
	fp=fopen(fname,"w");      /* 以w方式打开文本文件准备写入内容 */    
	if ( fp == 0 )	      	    /* 如果文件打开失败 */  
{ 	printf( "create new file error\n" );
		exit(1);
	}
	for (i=0;i<n;i++)           /* 记录条数n确知时可以这样控制循环 */
	{  /* 下面两条语句以相同的格式将记录分别写入文件和屏幕显示 */
	 fprintf( fp, "%d %-8s\t%.2f%6d\n", st[i].ID, st[i].name, st[i].score,st[i].rank );
     printf(  "%d %-8s\t%.2f%6d\n", st[i].ID, st[i].name, st[i].score,st[i].rank );   
	}
	fclose(fp);              /* 关闭文件 */                              
}