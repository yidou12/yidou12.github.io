/* 例11.3 某购物群购物，要求在文件D:\CV.txt的基础上追加几行，
每行是本次购买的每种产品的名称及数量，
从键盘输入以“$”结束并存入文件，
最后输出统计的文件总行数以及文件的完整内容。 
*/
/* li11_03.c: fputs,fgets函数示例 */   
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define N 100
int main( )
{	
    FILE *fp;                                                              
	char str[N];
	int lines=0;
    fp = fopen( "CV.txt", "a+" );    /* 以"追加"及可读可写的方式打开文件 */   
    if( fp == 0 )                    /* 如果文件打开失败 */                    
	{
		printf( "file error\n" );
		exit(1);
	}
	gets(str) ;                     /* 从键盘上读入一个字符串代表一种商品 */
	while( strcmp(str,"$")!= 0 )       /* 如果读入的不是"$"串则写入文件 */             
	{
		fputs(str,fp) ;               /* 将读入的字符串写入文件 */               
		fputc('\n',fp);               /* 在该串末尾写入一个换行符 */            
	    gets(str);                  /* 从键盘上继续读入一个字符串 */
	}
	rewind(fp) ;                    /* 让文件指针重新定位到文件开始位置 */     
	while (fgets(str,N,fp)!=NULL)     /* 从文件中读取一行内容放到str串中 */    
	{
		printf("%s",str);             /* 原样输出该字符串 */  
		lines++;                    /* 行数加1*/  
	}
	fclose(fp);			           /* 关闭文件 */                         
	printf("the file has %d lines.\n",lines); /* 输出统计的行数 */
	return 0;
}

