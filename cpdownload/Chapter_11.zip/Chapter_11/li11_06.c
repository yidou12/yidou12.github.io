/* 例11.6  使用fread函数读取文件D:\\computer.dat文件的内容
并输出至屏幕。
*/
/* li11_06.c: fread函数示例 */
#include<stdio.h>
#include<stdlib.h>
#define N 5
typedef struct Student
{
	int ID;					          /* 学号 */
	char name[20];				      /* 姓名 */
	double score;		                  /* 成绩 */
}STU2;
int main( )
{	
	FILE *fp;                                                            
	STU2 stu[N];
	int i=0,num;
	fp = fopen( "computer.dat", "rb" );	  /* 打开二进制文件, 读方式 */       
	if ( fp == 0 )						  /* 文件打开失败 */                 
	{
		printf( "file error\n" );
		exit(1);
	}
	fread( &stu[i], sizeof(STU2), 1, fp );  		/* 读取一个数据块 */             
	while( !feof(fp) )                      /* 将所有记录读出放在数组中 */     
	    fread( &stu[++i], sizeof(STU2), 1, fp );	/* 读取一个数据块 */             
	num=i;                              /* 用num记下记录条数 */
	for (i=0; i<num; i++)                   /* 集中输出所有的元素 */
		printf( "%d %-8s \t%.2f\n", stu [i].ID, stu [i].name, stu[i].score);
	fclose(fp);                                                            
	return 0;
}
